#!/bin/sh
# 检查全部模块：Toy 导入 Harness，Harness 导入 Game、PathCat
set -e
cd "$(dirname "$0")"
LC_ALL=C.UTF-8 agda src/Toy.agda
echo "all modules checked"
