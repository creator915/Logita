{-# OPTIONS --safe --cubical #-}
------------------------------------------------------------------------
-- Toy.agda —— 玩具实例：把 Harness 的每个参数填上最小的东西
--   棋盘   = 一个计数器 ℕ            世界 = 读、加
--   工具   = inc（加 k 并回报新值）、peek（读）
--   预言机 = 一个按脚本答题的 LLM     回答 = 加 k / 交给孩子加 k / 停
--   配置树 = 根（能开一个孩子）→ 叶（不能再开）
--   任务   = 把计数器弄到 5；验收 = 终值 ≡ 5
-- 文件末尾的几个 refl 就是"算出来的棋谱和终局"，新后端可以把它们打印出来。
------------------------------------------------------------------------
module Toy where

open import Cubical.Foundations.Prelude
open import Cubical.Data.Sigma
open import Cubical.Data.List
open import Cubical.Data.Maybe
open import Cubical.Data.Nat
open import Cubical.Data.Unit
open import Cubical.Data.Empty renaming (⊥ to Empty)
open import Game
open import PathCat

------------------------------------------------------------------------
-- 1 世界：计数器。两种事务：读 get，加 add k
------------------------------------------------------------------------
data WOp : Type where
  get : WOp
  add : ℕ → WOp

WSig : Sig
WSig = record { Op = WOp ; Res = wres }
  where wres : WOp → Type
        wres get     = ℕ
        wres (add _) = Unit

world : ℕ → (o : WOp) → Res WSig o × ℕ
world b get     = b , b
world b (add k) = tt , b + k

isSetWRes : (o : WOp) → isSet (Res WSig o)
isSetWRes get     = isSetℕ
isSetWRes (add _) = isSetUnit

------------------------------------------------------------------------
-- 2 预言机：一种（llm），按脚本答题。脚本用完就说 stop
------------------------------------------------------------------------
data OK : Type where
  llm : OK                 -- 要加 smt、clock、human：在这里多一个构造子

data Reply : Type where
  add!      : ℕ → Reply    -- "自己加 k"
  delegate! : ℕ → Reply    -- "让孩子加 k"
  stop!     : Reply

Q A : OK → Type
Q llm = ℕ        -- 提示词：当前计数
A llm = Reply    -- 回答

oracle : List Reply → (o : OK) → Q o → A o × List Reply
oracle []       llm _ = stop! , []
oracle (r ∷ rs) llm _ = r , rs

------------------------------------------------------------------------
-- 3 填参数：从这里起，Harness 里的一切都有了具体形状
------------------------------------------------------------------------
open import Harness OK Q A (List Reply) oracle WSig ℕ isSetℕ isSetWRes world ℕ ℕ
--            预言机 ────────────────────── 世界 ──────────────────── Spec Report

------------------------------------------------------------------------
-- 4 规则书：两个工具，都是 Free WSig 里的程序
------------------------------------------------------------------------
data Tool′ : Type where
  inc  : Tool′             -- 加 k，回报新值
  peek : Tool′             -- 读

Call′ : Tool′ → Type
Call′ inc  = ℕ
Call′ peek = Unit

impl′ : (t : Tool′) → Call′ t → Free WSig ℕ
impl′ inc  k = move (add k) λ _ → move get λ v → done v   -- 一次事务 = 两步
impl′ peek _ = move get λ v → done v

rules : Rules
rules = record { Tool = Tool′ ; Call = Call′ ; Result = λ _ → ℕ
               ; isSetResult = λ _ → isSetℕ ; impl = impl′ }

------------------------------------------------------------------------
-- 5 配置树：根能开一个孩子（Kids = Unit），叶不能（Kids = Empty）
------------------------------------------------------------------------
leaf : Config
leaf = node rules Empty (λ ())

root : Config
root = node rules Unit (λ _ → leaf)

------------------------------------------------------------------------
-- 6 策略树
------------------------------------------------------------------------
-- 叶的程序：不问模型，加 k 就回报。子 harness 可以是一段普通程序
leafProg : ℕ → Free (Sig-of leaf) ℕ
leafProg k = move (run inc k) λ v → done v

-- 根的检查器：回答 → Maybe 一步（反射点）
check : Reply → Maybe (Act rules Unit)
check (add! k)      = just (run inc k)
check (delegate! k) = just (sub tt k)
check stop!         = nothing

open Reflect rules Unit (λ _ → leaf) llm check   -- 给出 turn : ℕ → Free (Sig-of root) (Maybe (Step …))

-- 一步走完之后"当前计数"是多少：从记录里读
valueOf : ℕ → Step (Sig-of root) → ℕ
valueOf v (ask _ _    , _)       = v         -- 问了，没动
valueOf v (run inc  _ , v′)      = v′
valueOf v (run peek _ , v′)      = v′
valueOf v (sub _ _    , v′ , _)  = v′        -- 孩子的回报

-- 根的程序：先读一次，然后在预算内反复「问 → 检查 → 走」
loop : ℕ → ℕ → Free (Sig-of root) ℕ
loop zero    v = done v
loop (suc n) v = turn v >>= next
  where next : Maybe (Step (Sig-of root)) → Free (Sig-of root) ℕ
        next nothing   = done v
        next (just st) = loop n (valueOf v st)

rootProg : ℕ → Free (Sig-of root) ℕ           -- Spec = 预算
rootProg n = move (run peek tt) λ v → loop n v

leafStrat : Strat leaf
leafStrat = record { prog = leafProg ; kids = λ () }

rootStrat : Strat root
rootStrat = record { prog = rootProg ; kids = λ _ → leafStrat }

------------------------------------------------------------------------
-- 7 跑一局：脚本 = 自己加 2，让孩子加 3，停。起点 0，预算 3
------------------------------------------------------------------------
open Dynamics

script : List Reply
script = add! 2 ∷ delegate! 3 ∷ stop! ∷ []

demo : Position root 0                        -- 终点 + 棋谱 + 合法证明
demo = finish root rootStrat (rootProg 3) script 0

-- 算出来的终局是 5：验收 Accept = (_≡ 5) 由计算直接给出
accepted : Product (λ b → b ≡ 5)
accepted = fst demo , refl

-- 算出来的棋谱，逐条写开（refl 说明 Agda 算出的就是这个）
expected : Trace (Sig-of root)
expected = (run peek tt   , 0)                       -- 读：0
         ∷ (ask llm 0     , add! 2)                  -- 问：模型说自己加 2
         ∷ (run inc 2     , 2)                       -- 加：2
         ∷ (ask llm 2     , delegate! 3)             -- 问：模型说让孩子加 3
         ∷ (sub tt 3      , 5 , (run inc 3 , 5) ∷ [])   -- 子线：一步，夹着子棋谱
         ∷ (ask llm 5     , stop!)                   -- 问：停
         ∷ []

trace-is : fst (snd demo) ≡ expected
trace-is = refl

------------------------------------------------------------------------
-- 8 范畴在干什么：两局接成一条箭头；一次工具调用是对象层的一条箭头
------------------------------------------------------------------------
open Category

-- 同一脚本从 5 再跑一局到 10；两局接起来 = Fiber root 里 0 → 10 的一条箭头
demo′ : Position root 5
demo′ = finish root rootStrat (rootProg 3) script 5

both : Hom (Fiber root) 0 10
both = _⋆_ (Fiber root) (snd demo) (snd demo′)

both-len : length (fst both) ≡ 12
both-len = refl

-- 代理层的一步 run inc 2，在对象层是一条两步的箭头（add 2 , get）
one-tx : Hom Trans 0 2
one-tx = transOf rules inc 2 0

one-tx-is : fst one-tx ≡ (add 2 , tt) ∷ (get , 2) ∷ []
one-tx-is = refl
