{-# OPTIONS --safe --cubical #-}
------------------------------------------------------------------------
-- Harness.agda —— 整个范畴的骨架（三层塔）
--   底      配置 x（规则书：工具表 + 能开的子配置），一棵树
--   纤维    Fiber x：对象 = 棋盘，箭头 = 在 x 下合法的棋谱
--   纤维里  程序（策略） 对上 对手（预言机 × 世界 × 子 harness）
--   定理    不管预言机怎么答，跑出来的棋谱都是 Fiber x 里的一条箭头
-- 没有全局公理：预言机、世界、数据库……全是下面这个模块的参数。
------------------------------------------------------------------------
open import Cubical.Foundations.Prelude
open import Cubical.Foundations.HLevels
open import Cubical.Data.Sigma
open import Cubical.Data.List
open import Cubical.Data.Maybe
open import Game
open import PathCat

module Harness
  -- ① 预言机：智能与外部性的来源（LLM、人、时钟……）。只受类型约束，内容是参数
  (Oracle : Type) (Q : Oracle → Type) (A : Oracle → Type)
  (OState : Type) (oracle : OState → (o : Oracle) → Q o → A o × OState)
  -- ② 世界：对象层的签名与数据库。细节待补；这里只要它是一个确定的对手
  (WSig : Sig) (Board : Type) (isSetBoard : isSet Board)
  (isSetWRes : ∀ o → isSet (Res WSig o))
  (world : Board → (o : Op WSig) → Res WSig o × Board)
  -- ③ 子线两端传的数据
  (Spec Report : Type)
  where

------------------------------------------------------------------------
-- §0 对象层：世界是一个确定的对手；事务范畴
------------------------------------------------------------------------
Store : Comodel WSig Board
Store = record { resp = world }

-- 事务范畴：对象 = 棋盘，箭头 = 世界确实走过的一列步
Trans : Category
Trans = Build.Cat (Det.MachOf Store isSetBoard isSetWRes)

------------------------------------------------------------------------
-- §1 底：配置 = 规则书 + 孩子
------------------------------------------------------------------------
-- 一层的规则书：工具表。工具 = 对象层的程序（想法 4：态射，不是胶水）
record Rules : Type₁ where
  field
    Tool        : Type
    Call        : Tool → Type
    Result      : Tool → Type
    isSetResult : ∀ t → isSet (Result t)
    impl        : (t : Tool) → Call t → Free WSig (Result t)
open Rules public

-- 配置树：每个配置有自己的规则书和一族可开的子配置（▽ 的落点）
-- 子配置在开子线时就定了，整条子线不换配置——所以没有"沿底搬纤维"这回事
data Config : Type₁ where
  node : (r : Rules) (Kids : Type) (kid : Kids → Config) → Config

------------------------------------------------------------------------
-- §2 一层能走的三类步，与它们的回应：配置的签名
------------------------------------------------------------------------
data Act (r : Rules) (Kids : Type) : Type where
  ask : (o : Oracle) → Q o → Act r Kids          -- 问预言机
  run : (t : Tool r) → Call r t → Act r Kids      -- 动世界（走一次事务）
  sub : (k : Kids) → Spec → Act r Kids            -- 开子线

Sig-of : Config → Sig
Sig-of (node r Kids kid) = record { Op = Act r Kids ; Res = res }
  where
    res : Act r Kids → Type
    res (ask o q)  = A o                               -- 预言机的回答
    res (run t c)  = Result r t                        -- 世界的结果
    res (sub k sp) = Report × Trace (Sig-of (kid k))   -- 回报 + 子棋谱（△ 时并入父棋谱：树形）

-- 策略树：形状跟着配置树走，每个配置一个策略；子 harness 的策略是父策略的一部分
-- （玩具实例逼出来的：策略必须知道自己配置的工具表，所以不能是"对所有配置"的一个函数）
KidsOf : Config → Type
KidsOf (node r Kids kid) = Kids
kidOf : (x : Config) → KidsOf x → Config
kidOf (node r Kids kid) = kid

record Strat (x : Config) : Type where
  inductive
  field
    prog : Spec → Free (Sig-of x) Report            -- 这一层的程序
    kids : (k : KidsOf x) → Strat (kidOf x k)       -- 每个孩子的策略
open Strat public

------------------------------------------------------------------------
-- §3 纤维：在 x 下什么棋谱合法（静态：不看预言机的内部）
------------------------------------------------------------------------
-- 一次事务的净效果：(结果 , 新棋盘)
exec : (r : Rules) (t : Tool r) → Call r t → Board → Result r t × Board
exec r t c b = let e = Play.play Store (impl r t c) b in fst e , fst (snd e)

Mach : (x : Config) → Machine Board (Step (Sig-of x))

okOf : (x : Config) → Board → Step (Sig-of x) → Board → Type
okOf (node r Kids kid) b (ask o q  , a)         b′ = b ≡ b′                              -- 预言机：任何回答都合法，棋盘不动
okOf (node r Kids kid) b (run t c  , rs)        b′ = exec r t c b ≡ (rs , b′)            -- 世界：结果与新棋盘由世界定
okOf (node r Kids kid) b (sub k sp , (rep , t)) b′ = Build.Legal (Mach (kid k)) b t b′   -- 子线：子棋谱在子配置下合法

okPropOf : (x : Config) → ∀ b m b′ → isProp (okOf x b m b′)
okPropOf (node r Kids kid) b (ask o q  , a)         b′ = isSetBoard b b′
okPropOf (node r Kids kid) b (run t c  , rs)        b′ = isSet× (isSetResult r t) isSetBoard _ _
okPropOf (node r Kids kid) b (sub k sp , (rep , t)) b′ = Build.isPropLegal (Mach (kid k)) b t b′

okDetOf : (x : Config) → ∀ b m {b′ b″} → okOf x b m b′ → okOf x b m b″ → b′ ≡ b″
okDetOf (node r Kids kid) b (ask o q  , a)         e e′ = sym e ∙ e′
okDetOf (node r Kids kid) b (run t c  , rs)        e e′ = cong snd (sym e ∙ e′)
okDetOf (node r Kids kid) b (sub k sp , (rep , t)) l l′ = Build.legalDet (Mach (kid k)) t l l′

Mach x = record
  { ok = okOf x ; isSetPos = isSetBoard
  ; okProp = okPropOf x ; okDet = λ {b} {m} → okDetOf x b m }

-- 纤维范畴：对象 = 棋盘，箭头 = 在 x 下合法的棋谱
Fiber : Config → Category
Fiber x = Build.Cat (Mach x)

-- 代理层的一步 run，在对象层是一条箭头（一次事务）：上层的步是下层的路
transOf : (r : Rules) (t : Tool r) (c : Call r t) (b : Board)
        → Category.Hom Trans b (snd (exec r t c b))
transOf r t c b = snd (snd (Play.play Store (impl r t c) b))
                , Det.soundDet Store isSetBoard isSetWRes (impl r t c) b

------------------------------------------------------------------------
-- §4 对手族（动态）：预言机 × 世界 × 子 harness
------------------------------------------------------------------------
-- 策略树 st 是数据，不是公理：怎么拼提示词、怎么解析回答、何时停，S1/S4 再定
module Dynamics where

  opp    : (x : Config) → Strat x → Comodel (Sig-of x) (OState × Board)
  respOf : (x : Config) → Strat x → OState × Board
         → (m : Op (Sig-of x)) → Res (Sig-of x) m × (OState × Board)
  respOf (node r Kids kid) st (s , b) (ask o q)  = let e = oracle s o q in fst e , (snd e , b)
  respOf (node r Kids kid) st (s , b) (run t c)  = let e = exec r t c b   in fst e , (s , snd e)
  respOf (node r Kids kid) st (s , b) (sub k sp) =
    let e = Play.play (opp (kid k) (kids st k)) (prog (kids st k) sp) (s , b)   -- 子线：整条跑完才回来
    in (fst e , snd (snd e)) , fst (snd e)
  opp x st = record { resp = respOf x st }

  -- 一局的产出：终局棋盘、棋谱
  endOf   : (x : Config) (st : Strat x) {R : Type} → Free (Sig-of x) R → OState → Board → Board
  endOf   x st P s b = snd (fst (snd (Play.play (opp x st) P (s , b))))
  traceOf : (x : Config) (st : Strat x) {R : Type} → Free (Sig-of x) R → OState → Board → Trace (Sig-of x)
  traceOf x st P s b = snd (snd (Play.play (opp x st) P (s , b)))

  ----------------------------------------------------------------------
  -- §5 定理：对任何策略、任何预言机，跑出来的棋谱在 Fiber x 里合法
  --   范畴说合法；谁答什么（智能）全在参数里。
  ----------------------------------------------------------------------
  sound : (x : Config) (st : Strat x) {R : Type} (P : Free (Sig-of x) R) (s : OState) (b : Board)
        → Build.Legal (Mach x) b (traceOf x st P s b) (endOf x st P s b)
  sound x st (done a) s b = refl
  sound (node r Kids kid) st (move (ask o q) k) s b =
    b , refl , sound (node r Kids kid) st (k (fst (oracle s o q))) (snd (oracle s o q)) b
  sound (node r Kids kid) st (move (run t c) k) s b =
    snd (exec r t c b) , refl
    , sound (node r Kids kid) st (k (fst (exec r t c b))) s (snd (exec r t c b))
  sound (node r Kids kid) st (move (sub k sp) kk) s b =
    let e = Play.play (opp (kid k) (kids st k)) (prog (kids st k) sp) (s , b)
    in snd (fst (snd e))
     , sound (kid k) (kids st k) (prog (kids st k) sp) s b
     , sound (node r Kids kid) st (kk (fst e , snd (snd e))) (fst (fst (snd e))) (snd (fst (snd e)))

  ----------------------------------------------------------------------
  -- §6 局面与产品
  ----------------------------------------------------------------------
  -- 局面 = 棋盘 + 从起点到它的合法棋谱（= Fiber x 在 b₀ 下的余切片的对象）
  Position : Config → Board → Type
  Position x b₀ = Σ[ b ∈ Board ] Build.Hom (Mach x) b₀ b

  -- 一局跑完 = 一个局面（终点 + 棋谱 + 合法证明）；棋谱就是证据
  finish : (x : Config) (st : Strat x) {R : Type} (P : Free (Sig-of x) R) (s : OState) (b₀ : Board)
         → Position x b₀
  finish x st P s b₀ = endOf x st P s b₀ , traceOf x st P s b₀ , sound x st P s b₀

-- 产品 = 终局棋盘 + 验收证明（想法 1 在产品层的落点）；验收谓词由任务给
Product : (Accept : Board → Type) → Type
Product Accept = Σ[ b ∈ Board ] Accept b

------------------------------------------------------------------------
-- §7 反射点：数据 → Maybe 一步
------------------------------------------------------------------------
-- 预言机的回答是数据。只有经过检查器 check，它才获得"控制"的身份：
-- 成为一步——调工具、开子线（子实例就是这样被产出的）、或再问。
-- check 由程序调用，不由对手调用：对手只答题，程序决定"这段话算不算一步"。
module Reflect (r : Rules) (Kids : Type) (kid : Kids → Config)
               (llm : Oracle) (check : A llm → Maybe (Act r Kids)) where

  x : Config
  x = node r Kids kid

  -- 一回合的骨架：问一次 → 检查 → 要么走检查出的那一步并记下回应，要么停
  turn : Q llm → Free (Sig-of x) (Maybe (Step (Sig-of x)))
  turn q = move (ask llm q) (λ a → next (check a))
    where
      next : Maybe (Act r Kids) → Free (Sig-of x) (Maybe (Step (Sig-of x)))
      next nothing  = done nothing
      next (just m) = move m (λ rs → done (just (m , rs)))

------------------------------------------------------------------------
-- §8 三层塔（想法 9：上层的状态是下层的环境；上层的一步是下层的一条路）
--  层    环境（范畴）           状态（点）      一步              由谁答
--  编排  Config 树（本次不造）   x : Config      ▽ 开子线 (k , sp)  程序经 check 决定
--  代理  Fiber x                b : Board       ask / run / sub   预言机 / 世界 / 子 harness
--  对象  Trans                  b : Board       WSig 的一步        世界（确定）
--  棋盘里面（键 ↦ 值、代码态射）本次没进去：对象层只到"棋盘之间"。
------------------------------------------------------------------------
