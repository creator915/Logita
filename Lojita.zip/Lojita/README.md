# Lojita

用 Agda 写出一个编程 harness 的范畴骨架：**范畴说什么合法，智能在参数里**。

全部模块开着 `--safe --cubical`，没有一个 postulate：预言机（LLM、人、时钟……）、世界、数据库都是模块参数，所以每条定理都是「对任何预言机、任何世界」成立的。

```
 编排层   配置树 Config（底）      x ──▽ kid k──▶ x_子 ──▽──▶ …
                                   │ Fiber x          │ Fiber x_子
                                   ▼                  ▼
 代理层   纤维 Fiber x       棋盘 b ──棋谱 ask/run/sub──▶ 棋盘 b′      对象 = 棋盘，箭头 = 合法棋谱
                                   │ 一步 run
                                   ▼
 对象层   事务范畴 Trans     棋盘 b ──世界的一列步──▶ 棋盘 b′         工具 = 这一层的程序

 纤维里：程序（策略树 Strat x） 对上 对手（预言机 × 世界 × 子 harness）
 定理 sound：不管预言机怎么答，跑出来的棋谱都是 Fiber x 里的一条箭头
```

## 文件

| 文件 | 管什么 |
| --- | --- |
| `src/Game.agda` | 签名 → 程序（自由模型）、对手（余模型）、棋谱（由签名导出）、跑一局 |
| `src/PathCat.agda` | 机器（棋规）→ 范畴（合法棋谱）；确定对手的定理 `soundDet` |
| `src/Harness.agda` | 配置树、三类步 ask/run/sub、纤维、策略树、对手族、定理 `sound`、局面与产品、反射点 |
| `src/Toy.agda` | 玩具实例：计数器从 0 到 5，棋谱和验收都由 `refl` 算出 |
| `docs/walkthrough.md` | 逐段讲解（每段：为什么在这、它说什么、项目里的哪个词） |
| `docs/category-frame.md` | 一页结论：结构、决定、留白 |

## 检查

需要 Agda（≥ 2.6.3）和 cubical 库（在 `~/.agda/libraries` 里登记，库名 `cubical`）。

```
./check.sh        # = LC_ALL=C.UTF-8 agda src/Toy.agda，顺带检查其它三个模块
```

`LC_ALL=C.UTF-8` 不能省：错误信息里有 Σ、≡，非 UTF-8 环境下 Agda 会把错误本身吞掉。

已验证：Agda 2.6.3 + cubical v0.5，零警告。

## 现在在哪

骨架和玩具实例完成。下一步的候选（详见 `docs/walkthrough.md` 第 6 节与 8.5）：

- 数据库：把 `Board / WSig / world` 换成 Store（键 ↦ 值）与事务
- 策略：S1「状态 = 棋谱的 fold」、S4「提示词 = 投影」，换掉 Toy 里手写的 `valueOf` 与 `loop`
- 子线交错与合并（需要独立性证明）
