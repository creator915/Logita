# Lojita

用 Agda 写出一个编程 harness 的范畴骨架：**范畴说什么合法，智能在参数里**。

全部模块开着 `--safe --cubical`，没有一个 postulate：预言机（LLM、人、时钟……）、世界、数据库、运输、执行者都是模块参数，所以每条定理都是「对任何预言机、任何世界、任何执行者」成立的。

```
 编排层   配置树 Config（底）      x ──▽ kid k（边上带运输 Lifting）──▶ x_子 ──▽──▶ …
                                   │ Fiber x                              │ Fiber x_子
                                   ▼                                      ▼
 代理层   纤维 Fiber x       棋盘 b ──棋谱 ask/run/sub──▶ 棋盘 b′      对象 = 棋盘，箭头 = 合法棋谱
                                   │ 一步 run
                                   ▼
 对象层   数据库 Store       实例 s ──事务（一列 get/set）──▶ 实例 s′     工具 = 这一层的程序

 唯一的义务 Honest：对手每答一步都是 Fiber x 的一步
 定理 soundHonest：诚实的对手 + 任何策略 ⇒ 跑出来的棋谱是 Fiber x 里的一条箭头
 槽（à la Carte）：Lifting（每条边的运输）× (X, enter, leave)（上下文 lens）× Exec（执行者）× 对手（真 / 录音）
```

## 文件

| 文件 | 管什么 |
| --- | --- |
| `src/Game.agda` | 签名 → 程序（自由模型）、对手（余模型）、棋谱（由签名导出）、跑一局；状态 = 棋谱的 fold（`Resume`：resume / next 与两条定理） |
| `src/PathCat.agda` | 机器（棋规）→ 范畴（合法棋谱）；确定对手的定理 `soundDet` |
| `src/Harness.agda` | 配置树（边上带运输）、三类步 ask/run/sub、纤维、`Honest` 与 `soundHonest`、执行者 `Exec`、对手族 `Dynamics`（上下文 lens + 执行者为参数）、局面与产品、反射点（`turn` / `rounds`）、题单循环 `agenda`、驱动器（`OSig`、`drive`、`drive-agrees`） |
| `src/Store.agda` | 对象层数据库：实例与写、快照查询（cut）、方块 `Filled`（不同键机器填）、子 schema 的 lens（三条律）、沿 `ua` 搬运、给 Harness 的运输 `whole` / `realm` |
| `src/Replay.agda` | Rebuilder：`verify`（可判定的合法性 = verifying trace，只要 `VerCfg`）、录音对手 `wrap`（constructive trace）、`wrap-honest` |
| `src/ToyStore.agda` | 玩具实例：键值数据库上跑一局；换运输、换对手（录音回放、录音失效）；全部 `refl` |
| `src/Code.agda` | 代码的类型：语法树 `Raw`（照 Agda 的 Term，含串字面量与实例可见性）、IR 宇宙 `U / El`（含 `text`）、检查器作为预言机（反射点接后端）、工具表、洞表 |
| `src/CodeDec.agda` | 机械部分：`Raw` 可判定相等（生成的） |
| `src/ToyCode.agda` | 玩具实例：LLM 答代码、检查器变成值、程序走一步；回放、录音喂回程序、驱动器的两解释器一致，全部 `refl` |
| `src/Text.agda` | 文本可判定相等（内建单射原语） |
| `src/ToyText.agda` | P3：文本世界上的真工具（readK / writeK / evalP，从工具表生成）、两种题与两种槽、白名单 = 子线的 realm 运输（整回合在子线里，Spec 只传任务文本，根这一层可判定）、verify、驱动器 |
| `drive/` | 驱动器验收：回显答案（`*.answers`）、外部命令预言机样例 `llm-echo.sh`、`accept.sh` |
| `docs/drive.md` | 驱动器：P1–P3 的结构、协议、验收、决定、坑（2026-10-12） |
| `docs/code-type.md` | 代码的类型：结构、决定、坑；公式 X ≅ Γ₀ × (𝔑 ⇀ ▶X) × ▶(X→X) × Σ 重读（2026-10-12） |
| `docs/backend-hook.md` | 后端要写什么：驱动器（WHNF 循环、问 LLM、checkInternal、toRaw/fromRaw、落盘）（2026-10-12） |
| `docs/todo.md` | 最简可用原型 P1–P6，改自 对话.md（2026-10-12） |
| `docs/walkthrough.md` | 骨架四文件逐段讲解（2026-10-11） |
| `docs/category-frame.md` | 骨架一页结论（2026-10-11） |
| `docs/store-and-slots.md` | 数据库、Scheduler、Rebuilder：结构、槽、决定、留白（2026-10-12） |

## 检查

需要服务器上的 agda-cubical-run v3（默认的 `agda`）和 cubical 库（在 `~/.agda/libraries` 里登记，库名 `cubical`）。

```
./check.sh          # = LC_ALL=C.UTF-8 agda src/ToyStore.agda、src/ToyCode.agda、src/ToyText.agda，顺带检查其它模块
./run.sh            # 用 agda-cubical-run 把各玩具的项算到规范形，并驱动两局（先跑 check.sh）
./drive/accept.sh   # 驱动器验收（P2、P3）：要 agda-cubical-run v3（--cubical-drive）
```

`LC_ALL=C.UTF-8` 不能省：错误信息里有 Σ、≡，非 UTF-8 环境下 Agda 会把错误本身吞掉。

目标编译器：服务器上的 agda-cubical-run v3（Agda 2.9.0）+ cubical-0.9（commit 9216603），零警告，零 postulate；不迁就其它版本。cubical-0.9 把 `--guardedness` 设为传染性选项，所以 `lojita.agda-lib` 写了 `flags: --guardedness`；Agda 2.9 拒绝对无护卫的递归 record 开 eta，所以 `Strat`、`DecCfg`、`VerCfg` 写了 `no-eta-equality`。

## 现在在哪

骨架、数据库、Rebuilder、Scheduler 的槽都在；代码的类型定了（LLM 答的是 Agda 语法树，检查是预言机里的一步）。P1–P3 完成（详见 `docs/drive.md`）：

- P1 状态 = 棋谱的 fold：`resume / next`，两个玩具改用 `rounds`
- P2 驱动器：Agda 侧 `drive` + 定理 `drive-agrees`；后端 v3 的 `--cubical-drive`（回显 LLM、外部命令、checkInternal）。回显跑出的棋谱与 Agda 里算的逐字相同
- P3 文本世界上的真工具：LLM 写值与程序，后端检查，程序在白名单子线里跑，verify 通过

下一步（`docs/todo.md`）：P4 提示词 = 棋谱的 fold，真 LLM 接到 `cmd:` 上；P5 名字表进包、录音对位；P6 第一个真任务。
