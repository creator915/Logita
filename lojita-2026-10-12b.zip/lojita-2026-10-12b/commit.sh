#!/bin/sh
# 用法：在 Lojita 仓库根目录执行  sh /path/to/lojita-2026-10-12/commit.sh
# 作用：复制本包的文件进仓库（新增 Text / ToyText、drive/ 与 docs/drive.md，更新其余），提交一次
set -e
here="$(cd "$(dirname "$0")" && pwd)"
mkdir -p src docs drive
cp "$here"/src/*.agda src/
cp "$here"/docs/*.md docs/
cp "$here"/drive/* drive/
cp "$here"/README.md "$here"/check.sh "$here"/run.sh "$here"/lojita.agda-lib .
git add -A
git commit -F "$here"/COMMIT_MSG
echo "committed; now: git push"
