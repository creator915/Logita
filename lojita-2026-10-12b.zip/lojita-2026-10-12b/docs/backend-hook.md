# 后端要写什么：agda-cubical-run 的驱动器（2026-10-12；同日实现为 v3，见下面第一节）

## 实现（v3，2026-10-12）

已写完、已装成服务器默认的 `agda`（原版 v2 在 `/usr/local/bin/agda-cubical-run.v2`，原 `Runtime.hs` 在 `/root/agda-backend/Runtime.v2.hs`）。`Runtime.hs` 333 → 1218 行：原有部分只动了选项、分派，并把 export 拆出 `exportPacket`；新增的整段在文件末尾 "Driver"。参数与协议见 drive.md；这里只记与下面原计划不同的地方。

| 原计划 | 实际 |
| --- | --- |
| 认 `(inl llm , q)` / `(inr f , r)` | 认 `inr`（cubical 的 `_⊎_`）且回答类型是 `Maybe τ` → 检查器；其余一律当外部预言机（不止 LLM：人、脚本、任何命令） |
| 回答的目标类型"随 P4 定" | 回答类型是 `Code.Raw` → 代码模式（`inferExpr'` + `ExpandLast`，quote 成 Raw）；其它 → 值模式（按回答类型检查） |
| 解析失败：重问或哨兵 | 哨兵 `sort 0`；铸新名字（带模式的 λ）也算解析失败 |
| 目标类型 = 规范化 `El (codeOf f)` | 取续体定义域（`move` 的构造子类型代入参数），弱头形式；日志里读作 `El (codeOf f)` |
| toRaw / fromRaw 机械翻译 | 另有三件事：重载字面量求值回字面量；Level 参数按头的类型丢掉、解码时补 `lzero`；`Vis` 多了 `ins` |
| Name = ℕ + 按包固定的表 | 每次运行一张表，按阅读顺序编号，日志末尾打印；进包是 P5 的事 |
| 约 60 + 40 行 | 约 800 行（名字表、Level、失败路径、日志） |
| 落盘与回放 | 落盘做了（`--cubical-term-file`）；回放（import → wrap → drive）没做，P5 |

回归：自带 `run-tests.sh` 通过；transport 矩阵与 V2-RESULTS 相同。

---

以下是写之前的计划（原文保留）。

接续 claude_cubical-runtime-backend.md（后端现状）、code-type.md（反射是预言机里的一步）、对话.md 的 IO 转发层方案。原则：**Agda 侧 --safe 全部保留，一个 postulate 都不要；后端只做签名的余模型**。模型内的一切（run、sub、棋盘、棋谱）由 Agda 函数算，后端只在两种步上出面：问 LLM、查代码。

## 形状
```
 Agda（--safe）                                         Runtime.hs（现有 330 行 + 一段）
   OSig = Σ Oracle Q，Res = A                              OSig 的余模型住在这里：
   drive : Free (Sig-of x) R → W → Free OSig (R × W × Trace)   归约 drive P w 到 WHNF：
     = Dynamics.opp 的 oracle 那一行换成 move，其余照抄          done (r , w , t)  → 结束，交 verify
                                                               move (inl llm , q) k → 问 LLM → 喂 k
                                                               move (inr f  , r) k → checkInternal → 喂 k
```
`drive` 是纯 Agda（to-do P2 的 Agda 半边，约 40 行）。后端是一个循环：WHNF → 看头 → 喂续体 → 再 WHNF。t16 的 import 路径已经有"检查 → 喂消费者 → 归约"，这里只是把入口从命令行换成归约过程中遇到的 `move`。

## 后端要做的五件事
1. **循环**：`--cubical-drive='drive P w'`。对项反复 `reduce` 到 WHNF；匹配 `Con done [a]` / `Con move [o , k]`。`o` 再 WHNF 到 `(inl llm , q)` 或 `(inr f , r)`（Σ 的构造子 + ⊎ 的构造子）。
2. **问 LLM**：`q` 规范化后打印成提示词（P4 之前提示词的拼装在 Agda 里是 `Q llm` 的一个 fold，后端只打印）。回答是 Agda 源码文本：`parseExpr → concreteToAbstract → checkExpr`（目标类型随 P4 定，最初是 `Raw` 本身或一个一阶类型）→ 内部 `Term` → **toRaw** 成 `Raw` 数据类型的值 → 喂给 `k`。解析失败：重问（后端的外循环），或喂一个过不了检查的哨兵树（玩具用 `sort 0`）。
3. **查代码**：`move (inr f , r) k`。目标类型 = 规范化 `El (codeOf f)`（或直接取 `k` 的定义域规范化后的 `Maybe` 参数）。**fromRaw** 把 `r`（`Raw` 的值）翻回内部 `Term`，`checkInternal t ty`；通过 → 喂 `just t`，不通过 → 喂 `nothing`。同一进程内 Σ 自然相同，不用再比哈希。
4. **toRaw / fromRaw**：`Term ↔ Raw` 的机械翻译，按 Code.agda §1 的表：`Var i es ↔ var i es`、`Lam ↔ lam`、`Lit ↔ lit`、`Def/Con ↔ def/con`、`Pi ↔ pi`、`Sort ↔ sort`、`MetaV ↔ meta`；`Elim`：`Apply ↔ app`、`Proj ↔ proj`、`IApply ↔ pth`。绑定名、Level、DontCare 在 toRaw 里丢掉（fromRaw 补默认）。往返律 `fromRaw (toRaw t) ≡ t` 对无 Level 的项成立，作为后端自测。
   - **Name 怎么编码**：玩具里 `Name = ℕ`。真跑时建议 `Name = ℕ` + 一张按包固定的名字表（下标 ↦ QName），表进哈希；或 `Name = String` 走 `lookupName`。两种都行，选一种写进包格式。
   - **Meta**：`MetaV` 只在编辑器里出现；驱动器里遇到带 meta 的项直接判不通过。
5. **落盘与回放**：棋谱 `t : Trace (Sig-of x)` 是 `drive` 的产出，用现有 export 打包（它就是一个封闭项）。重启 = import 包 → 构造 `wrap x d C L` 的起点 `(w₀ , t)` → 再 `drive`。跑完在 Agda 里 `verify x d b₀ t`（规范化）核对终局；`verify-sound` 给合法性。

## 不做的
- 不在后端解释 Store 的 get/set：世界在模型内，`run` 由 Agda 的 `exec` 算。
- 不做 β 代入带谱的洞：驱动器不碰 `meta`。
- 不比 Σ 哈希：包格式已经比了。

## 验收
- 用一个"回显脚本"当 LLM（后端读一个文件逐条回答），驱动 ToyCode 的 `rootProg 8`，得到的棋谱与 `ToyCode.theTrace` 的规范形逐字相同（`--cubical-run='theTrace'` 对照）。
- 故意给一个过不了检查的回答，棋谱里对应的 check 步回应为 `nothing`。
