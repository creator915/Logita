# 代码的类型：Code.agda、CodeDec.agda、ToyCode.agda（2026-10-12；同日补：串字面量、实例可见性、text 码，见文末）

接续 store-and-slots.md、decisions 3（LLM 写、Agda 查）、想法 5（物化与反射）、world-and-later（▷）、sigma-vs-names（键是角色）、four-component-reading（公式）。本次用户否决了"自造一个 Script 小语言"，改为：**Code 就是 Agda 自己的语法树**；检查器不重造，**接通后端**——反射是签名里的一步，余模型住在 Haskell。全部 `--safe --cubical`，零 postulate；Agda 2.6.3 + cubical v0.5 零警告。

## 一句话
```
 这一拍（数据）                 反射点 = 预言机里的一步                        下一拍（控制）
 Raw ─── ask (inr f) r ──▶ 后端对 r 跑 checkInternal（目标类型 = El (codeOf f) 规范化）──▶ Maybe (El (codeOf f))
                              通过把值喂给续体 k，不通过喂 nothing                      k 就是"下一拍"
```
`Act` 一个字不改：检查器是 `Oracle` 的一员（`Oracle = Oracle₀ ⊎ Fp`）。`okOf (ask …)` = 棋盘不动，检查不碰 Store。

## Code.agda（193 行）
- §1 `Raw` 照 Agda 的 `Term` 画（对照了 2.9 主干的 Syntax/Internal.hs）：`var lam lit def con pi sort meta` + 消去谱 `Elim = app | proj | pth`。de Bruijn；绑定名、Level 项、DontCare/Dummy 不进。`def/con/proj` 引的是键（角色）。
- §2 `U / El` 归纳–递归：`nat unit bool name π σ _≡ᵘ_ list maybe program code later`。`El code = Raw`（宇宙含自己的语法，不含自己的语义）。`El (later a) = Unit → El a` 占位。
- §3 `Checker`：`Oracle = Oracle₀ ⊎ Fp`，`Q (inr f) = Raw`，`A (inr f) = Maybe (El (codeOf f))`；`Dyn` 把原预言机与检查器的动态并起来（检查器状态 SC 装 Σ；真跑时 `chk` = 后端，玩具里 = 表）；`decOracle / decQ` 只比指纹和树（备选 A）。
- §4 `ToolEntry / Tools`：`Call / Result / impl` 由 `El` 算出，正是 `Rules` 的四样。
- §5 `Holes = Meta → Maybe Raw`（= Store Meta Raw 的 Board），`zonk`（带谱的洞留给后端 β）。

## CodeDec.agda（288 行，生成的）
`discreteRaw / discreteElim / discreteElims`、`isSetRaw`。按构造子表生成：每个构造子一个"是不是它"谓词 + 每个参数一个 `Maybe` 投影；改 `Raw` 就重生成。

## ToyCode.agda（169 行，全部 refl）
预言机 = 脚本 LLM（答树）⊎ 检查器（槽 `natSlot`，码 `nat`，替身只认 `lit (natL n)`）。程序每回合：问 LLM → 问检查器 → `just n` 就 `run incX n`，`nothing` 就停。脚本 `[2, 3, def 7 []]`：终局 x = 5；棋谱 8 条，LLM 的回答是语法树、检查那步的回应是 `Maybe ℕ`；回放逐字相同、脚本一条没消费。

## 决定
1. 不在 Agda 里重造检查器；`decode / reify / Builtin / FO` 全删。反射 = `ask (inr f) r`，动态是参数。
2. 回放对位按语法（指纹 `f` + 树 `r`），不按语义（`U` 不可判定）。Σ 哈希在后端的包格式里，不进 Agda。Rebuilder 的作用是"前提变了没"，哈希够用。
3. `--guarded` 不在 Agda 的 unsafe 列表里，但要 postulate Tick/dfix/pfix，所以不用；宇宙含自己下一拍（`El univ = ▷U`）在 --safe 下被正性拒绝（已实测）。
4. `later` 先占位；真正的拍 = 后端归约 `move (ask (inr f) r) k` 时的 `k`。

## 公式 X ≅ Γ₀ × (𝔑 ⇀ ▶X) × ▶(X→X) × Σ 重读（本次三轮讨论，结论：形式不用改）
- **孩子的类型由码决定**：`𝔑 ⇀ Σ[ k ∈ Kids c ] ▶ X (kid k)`——码 k 现在就有（数据），实例 `X (kid k)` 下一拍（控制）。Harness 的 `node r Kids kid lf` 本来就是这个形状，`Sig-of / Mach / Strat` 递归穿过 `kid k` 靠的正是 IR 那条终止规则。选 k（LLM）和查（后端）不机械，`kid` = El 机械。
- **𝔑 是花名册，不是白名单**：名字开的时候铸造，dom 有限。限制在三处：只能长在自己下面（confinement）、种类由父配置定、开了要能活（σ ⊨ d 从 restrict 过的视图满足、资源 enter、预算）。开**实例**随便（资源够就行），开**种类**受限；铸新种类的权力本身是父配置里的一个键（`cfgSlot ∈ Fp`），DSH 里模型没有这个键、loader 有。
- **"现在开着谁"在 Agda 里不是表，是日志的 fold**：打开了还没合上的括号。同步 `sub` 下它恒等于嵌套深度，一行不用写；孩子活过一步（并发子代理、jobs、长住插件、世界线分叉）时它才成为 `Pos` 的一个分量、`Legal` 的几条规则。𝔑 是异步的代价。
- **种类的宇宙就是接口范畴，已在 Store 里**：对象 = realm（+ 资源需求 + 工具的码），箭头 = Lifting（restrict/merge lens）。父亲有权开的种类 = 切片 `Iface / c`。限制写在接口上（可判定），不写在 Raw 上；体另查。
- **实例的类型**：`X c = c（固定索引）× Σ_c（restrict 过的棋盘 + 资源余额 + 谁在任，变）× 𝔑（变，异步才有）× 棋谱 + 合法证明（只增，= 账本，就是 Position）`。运行只动纤维，从不动底。资源与 𝔑 的联动是守恒引理，不是类型。

## 补（P2–P3 落地后，2026-10-12）
- `Lit` 加 `strL : String → Lit`（Agda 的 LitString；世界的值是文本）；`Vis` 加 `ins`（实例参数 ⦃ x : A ⦄，Agda 的 Instance）；`U` 加 `text`，`El text = String`。String 的可判定相等在 `Text.agda`（内建单射原语，--safe 允许）。`CodeDec` 手写的两段（Vis、Lit）改成按构造子序号比，Raw 那段没动。
- 决定 5：LLM 的代码只能引用岗位表里已有的名字。带模式的 λ、where 会铸新定义——后端判为非代码，喂哨兵 `sort 0`。铸新种类的键是 S7 `cfgSlot` 的事，这里不开口子。
- 决定 6：重载字面量在 quote 之前求值消掉。cubical 绑定了 FROMNAT，类型未知时 `2` 被解析成 `fromNat ⦃…⦄ 2`；后端把它算回字面量，树里就是 `lit (natL 2)`。
- ToyCode 脚本第三条改成 `sort 0`：后端按出现先后编号名字，`def 7 []` 里的 7 不对应任何东西；LLM 答 `Type` 时解析出来的正好是 `sort 0`。

## 实测的坑
- 2.6.3 终止检查器不认 `f (list a) xs`（码不变、列表变短），要拆辅助函数。
- `prog` 与 `Strat.prog` 撞名，U 的构造子改叫 `program`。
