# To-do：最简可用原型（2026-10-12，改自 对话.md 的 P1–P6；同日 P1–P3 完成，见 drive.md）

验收标准（定义"可用"）：**一个真任务**端到端跑完——给定几个键上的内容和一个失败的验收谓词，LLM 读、写、停；棋谱落盘；断电重跑 = 回放，LLM 零调用；`verify` 通过。

每项标槽位（三槽规则：Σ 操作 / 解释器子句 / 引理；机外的单独标）。与 对话.md 相比改了三处：**世界全在模型内**（没有 bash、readF、writeF，只有 Store）；**检查器不在 Agda 里造，是预言机里的一步**（P3 的 decode/Script 删掉）；**棋谱序列化用后端的包，Agda 不写编码**（P5 的 encode/decode 删掉）。

## P1 状态 = 棋谱的 fold（S1，--safe，全 refl 尺）✅
> 完成：`Game.Resume`（resume / next / next-play / resume-play）；`Harness §7` 的 check 改成程序（Kleisli），`rounds` 题单 = 预算；两个玩具的手写循环删掉；尺：ToyStore `inr 3`、ToyCode `inr 2`，`refl`。

1. `resume : Free S R → Trace S → (Free S R) ⊎ R`：把录音喂给程序（用 `decOp` 核对步）。解释器子句。
2. `next = 头一步 ∘ resume`；引理：`next` 给出的步就是 `play` 会走的步。引理。
3. 用 `Reflect.turn` + 预算改写 `rootProg`，删掉手写循环；ToyCode 的回合"问 LLM → 问检查器 → run"写成 `turn` 的一个实例。
   尺：ToyStore / ToyCode 的 `theTrace` 经 `resume` 回到 `done`，`refl`。

## P2 驱动器（接通后端，详见 backend-hook.md）✅
> 完成：`Harness §9`（OSig、oracleC、drive、drive-agrees）；后端 v3（`--cubical-drive`、`--cubical-oracle=file:/cmd:/stdin`、`--cubical-drive-then`）。回显 2 / 3 / Type 跑出的棋谱与 theTrace 逐字相同；坏回答 → `nothing`。
> 与计划不同：ToyCode 脚本第三条改成 `sort 0`（LLM 答 `Type` 时解析出来的就是它）；后端约 800 行而不是 100 行。

4. Agda：`OSig = Σ Oracle Q`（`Res = A`）；`drive : Free (Sig-of x) R → W → Free OSig (R × W × Trace)` = `Dynamics.opp` 的 oracle 那一行换成 `move`，run / sub 照抄。解释器子句。引理：`drive` 对任何 OSig 的余模型 `C` 跑出的棋谱 = `opp` 用同一个 `oracle` 跑出的棋谱（两解释器一致，dev-order 第 2 把尺）。
5. 后端：WHNF 循环、问 LLM、`checkInternal`、`toRaw / fromRaw`、落盘。机外，Haskell，约 60 + 40 行。
   尺：回显脚本当 LLM 驱动 `ToyCode.rootProg 8`，棋谱与 `theTrace` 逐字相同；给一个坏回答，check 步回应 `nothing`。

## P3 真工具与世界（S3，--safe）✅
> 完成：`ToyText.agda`。键 = ℕ（不是 Fin n），值 = String（`Text.agda`）；`Code` 加 `strL`、`text`、`ins`；evalP 走"查 + 跑是 turn 的两步"，verify 只要 `VerCfg`；守卫 = 子线的 realm 运输，整回合在子线里做、Spec 只传任务文本（程序不穿过边界，根这一层全部可判定：`decRootOp`）；`Harness §7` 加题单循环 `agenda`。后端驱动三局，verify 都返回 just，白名单外的写被挡住。

6. 世界 = Store，K = 文件表（`Fin n`），V = 文本（`List Char` 或库里有的可判定相等的串）。工具：`readK : K → Maybe V`、`writeK : K → V → Unit`，都是 `Free WSig` 里两步程序；`Rules` 从 `Code.Tools` 的表生成。Σ 操作。
7. LLM 写的是**值与程序**，不是新工具：`Fp = { valSlot k（码 = maybe text）, progSlot（码 = program unit）}`；程序经 `ask (inr progSlot) r` 查过后用一个固定工具 `evalP : program unit → Unit` 跑（`Call evalP = El (program unit)`——录音时按 `decQ` 比的是树 `r`，所以 `Call` 可以不是 Discrete：把 `run evalP p` 改成 `run evalP r`，`impl` 先查后跑，或者就把"查 + 跑"写成 `turn` 的两步）。先定一种，不要两种都做。
8. 管线先只做一层：守卫"只能否决"（键的白名单 = realm，Store §7 已有 `confineL`）。引理：守卫可交换，留到有第二个守卫再证。
   尺：`verify` 对真跑出的棋谱返回 `just`。

## P4 模型边界（S4）
> 已有：后端的 `cmd:` 预言机（stdin 收提示词、stdout 交代码）；代码模式的解析在后端（第 10 条已做：解析失败喂哨兵，不重问）。还缺：`prompt` 这个 fold；真 LLM 的适配器。

9. `prompt : Trace → Q llm`：一个 fold（任务 + 最近 k 步 + 工具表 + 当前键的内容）。解释器子句。后端只把它打印成文本。
10. 回答的解析在后端：parse / scope / check Agda 源码，**不解析 JSON、不设行协议**；解析失败重问。机外。
    尺：同一棋谱两次 `prompt` 相同（幂等，`refl`）。

## P5 记忆（S5）
> 已有：`--cubical-drive … --cubical-term-file=包` 把结果落盘，`--cubical-import` 读回（第 11 条的前一半）。还缺：名字表进包（不然 `def n` 的 n 跨运行是漂的）；不可判定只剩子线里 evalP 的调用参数一处，录音对位要另定（只按工具对位，或用树的指纹）。

11. 棋谱落盘 = 后端 export 包（棋谱是封闭项）；重启 = import → `wrap` → `drive`。机外。
12. Rebuilder 的"前提变了没" = 包的 Σ 哈希；哈希不等则整条录音作废（不做部分续跑）。
    尺：断电重跑，LLM 调用次数为 0；改一个定义再跑，录音被拒。

## P6 跑一个真任务
13. 任务：3 个键（一段文本、一个"测试"谓词的描述、一个输出键）；`Accept : Board → Type` 是输出键上的谓词；预算 10 轮。
14. 记录：棋谱、`verify` 结果、LLM 调用次数、回放一致性。第一条真实数据。

## 之后（不进原型）
- S7 配置写成数据：`Iface`（realm × 资源需求 × 工具的码）与接口范畴（箭头 = Lifting）；`Kids c = Iface / c`（切片）；`cfgSlot ∈ Fp` 是铸新种类的键；`kid` = El。公式不改（见 code-type.md）。
- S6 异步：jobs / 并发子代理 / 长住插件。那时 `Pos` 多一个分量 `𝔑 ⇀ Σ[ c ∈ Cfg ] 账本`，`Legal` 多 open/close/use 三条；资源守恒引理。
- 编辑器：`Holes` 的填洞事务用 `Trans`；带谱洞的 β 代入；光标 = Raw 的导数。

## 明确不做
资源账 `X`、restarting、同键证书、回应层面的方块、Guarded Cubical（postulate）、Agda 内检查器、`Tick`。

## 顺序理由
P1 不碰边界、全是 refl 尺；P2 之后每一步都能真跑；P3 前用回显 LLM 和内存 Store 把 `drive` 调稳，再放真 LLM 进来。P1–P2 一个会话，P3–P4 一个，P5–P6 一个。
