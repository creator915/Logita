# 驱动器：P1–P3 落地（2026-10-12）

接续 todo.md（P1–P6）、backend-hook.md（后端要写什么）、code-type.md（代码的类型）。本次把 P1、P2、P3 做完并在服务器上验收；Agda 侧全部 `--safe --cubical`、零 postulate；后端是 agda-cubical-run v3（`Runtime.hs` 新增一段，已装成服务器上的默认 `agda`）。

## 一句话

同一个程序，两个解释器。`opp`：预言机在 Agda 里作答。`drive`：把 ask 交出去，由后端作答——问外部预言机，或者 checkInternal。两边跑出的棋谱逐字相同：玩具里是 `refl`，后端跑出来的与 `--cubical-run=theTrace` 逐字对照。

```
                    程序 P : Free (Sig-of x) R
               ┌───────────────┴───────────────┐
         opp（Agda）                      drive（Agda：ask 那一行换成 move）
     预言机在模型里作答                  Free OSig ──后端：WHNF → 作答 → 喂续体 → 再 WHNF──▶ 结果
               │                          (inl o , q) → 外部预言机（文件 / 命令 / stdin）
               │                          (inr f , r) → 解码 Raw → checkInternal → just t / nothing
               ▼                                   ▼
            棋谱 T   ═════ drive-agrees ═════   棋谱 T′ ──verify──▶ 合法（verify-sound）
```

run 和 sub 不出 Agda：世界在模型内，后端从不碰棋盘。

## P1 状态 = 棋谱的 fold

- `Game.Resume`（参数：步的可判定相等）：`resume P t` 把录音一条条喂给程序——喂完交出余程序（`inl`），程序先停交出结果（`inr`），对不上就停在这一步；`next = headOp ∘ resume`。
- 定理：`next-play`（喂 `play` 跑出的棋谱前 n 条，`next` 恰是第 n+1 步）、`resume-play`（整条喂完正好停在 `play` 的结果上）。关键引理 `resume-hit`：可判定 ⇒ 步是集合 ⇒ 自环路径就是 `refl`，回应原样交出。
- `Harness §7` 重写：`Check x = Q llm → A llm → Free (Sig-of x) (Maybe (Op (Sig-of x)))`——check 本身是一段程序，所以"问 LLM → 问检查器 → run"是 `turn` 的实例；`rounds`：题单就是预算，交出走成的回合数。x 作为参数传进来再拆开（在模块参数里重拼 `node` 不行：两个 `λ ()` 不是同一个函数）。
- 两个玩具的手写循环删掉了。尺：ToyStore `resume … theTrace ≡ inr 3`、`next-3`、`next-end`、`resume-done′`（由一般定理直接得到）；ToyCode `≡ inr 2`、`next-1`。全部 `refl`，旧的 refl 测试一条没动。

## P2 驱动器

**Agda 半边（Harness §9）**：`OSig = { Op = Σ Oracle Q ; Res = A ∘ fst }`；`oracleC`（拿 oracle 本身当 OSig 的余模型）；`Drive X enter leave`：`WD = Board × X`（没有预言机状态——它在机外），`drive`，`shape`，定理 `drive-agrees`：`play (opp x st) P (s , b , xx) ≡ shape (play oracleC (drive x st P (b , xx)) s)`。证明用 `Game.PlayLaws` 的 `play-mapF`、`play->>=`。ToyCode 里 `driven-trace`：棋谱与 §5 逐字相同，`refl`。

**后端半边（Runtime.hs v3）**

| 参数 | 作用 |
| --- | --- |
| `--cubical-drive=EXPR` | 要驱动的项，类型必须是 `Free S A` |
| `--cubical-oracle=file:路径` | 回显：每行一个回答（空行与 `#` 行跳过）；答完了：代码模式喂哨兵，值模式报错 |
| `--cubical-oracle=cmd:命令` | 每问一次起一个 `sh -c 命令`：stdin 收提示词，stdout 交回答。真 LLM 的适配器就是这个形状（`drive/llm-echo.sh`） |
| `--cubical-oracle=stdin` | 默认：提示词打到 stderr，人从 stdin 答 |
| `--cubical-drive-then=函数` | 跑完套在结果上再打印；可以给多个。要用有名字的定义（λ 推不出类型，import 路径同样） |
| `--cubical-term-file=文件` | 结果写成包（与 export 同格式），`--cubical-import` 读回 |

日志（每一步问了什么、答了什么、树、过没过、名字表）走 stderr。

协议（后端只认这些）：

1. 一步 `(o , q)`：o 的头是 `inr`（cubical 的 `_⊎_`）且回答类型是 `Maybe τ` → **检查器**；其余 → **外部预言机**。
2. 外部预言机的回答类型是 `Code.Raw`（按名字和构造子表认）→ **代码模式**：解析 → 作用域 → `inferExpr'` 带 `ExpandLast`（补尾部的隐式/实例参数）→ 重载字面量（`fromNat`/`fromString`/`fromNeg`）求值回字面量 → quote 成 Raw。不是代码（语法错、作用域错、推不出类型、铸了新名字）→ 哨兵 `sort 0`，没有检查会收它。其它回答类型 → **值模式**：按回答类型检查，直接喂。
3. 检查器：把树规范化、解码成内部项（开项、洞、未知名字、`def` 指构造子、`con` 指非构造子 → 不通过），`checkInternal` 对 τ → 通过喂 `just t`，否则 `nothing`。
4. 名字编成 ℕ：一张名字表，按阅读顺序第一次出现编号（每次运行一张，日志末尾打印）。Level 参数：quote 时按头的类型丢掉，解码时按类型补 `lzero`。

## P3 文本世界上的真工具（ToyText.agda）

```
 根 root：工具 readK / writeK；题单（agenda）里两种题
   keyTask k  ：根自己做一回合：问 LLM「fillKey k」→ 查（码 maybe text）→ run writeK (k , v)
   codeTask t ：开子线，只传任务文本 t（Spec = String）
                  │ 运输 = realm white：白名单外的键看不见、写不回
                  ▼
 子 runner：工具 evalP；整回合在这里做
   问 LLM「writeCode t」→ 查（码 program unit）→ run evalP p，回报走成的回合数
```

- 程序 p 在子线里产生、在子线里用掉，从不穿过子线边界。所以根这一层的步全部可判定——`decRootOp : Discrete (Op (Sig-of root))` 类型检查通过，`same-task` / `other-task` 两条 refl 用它真算了一次。不可判定的只剩子线里 evalP 的调用参数一处。
- 问 LLM 的题是一个小类型 `Ask = fillKey k | writeCode t`：题带着键号或任务文本进提示词（P4 的提示词在它上面长）。
- `Harness §7` 加了一般的题单循环 `agenda`：每一题是一段交出「走成没有」的程序；`rounds` 是它的特例（每题都先问预言机），而「开一条子线」这种题本层不问预言机。
- `Text.agda`：String 可判定相等（内建的两条单射原语，不是公设）。`Code`：字面量加 `strL`，宇宙加 `text`，可见性加 `ins`。`Replay`：拆出 `VerCfg`——verify 只要工具结果可判定。
- 工具都从 `Code.Tools` 的表生成（`rulesOf`）。LLM 可用的名字：`rd`、`wr`、`orElse`、`_>>=_`。
- Agda 里拿玩具检查器（只认几种树形）跑一局：`final-5 : fst result 5 ≡ nothing`（写了，被运输挡住），`steps`（根这一层 7 步），`verified`，`driven-trace`，全部 `refl`。

## 验收（drive/accept.sh，10 项全过）

| 项 | 回答 | 结果 |
| --- | --- | --- |
| P2 ToyCode | `2` `3` `Type` | 棋谱与 theTrace 逐字相同；verifyX = `just (just 5)` |
| P2 坏回答 | `Type` / `true` / `)(` | 检查那一步回应 `nothing` |
| P3 第一局 | `wr 2 "hello"` `just "world"` `wr 5 "evil"` `true` | 棋谱与 theTrace 逐字相同（根 7 步，两条子线各带自己的棋谱）；verify = `just ("input text" , "world" , "hello" , nothing)` |
| P3 第二局（cmd:） | `wr 5 "evil" >>= λ _ → wr 0 "edited"`、`just "world"`、`rd 0 >>= λ m → wr 2 (orElse "none" m)`、`)(` | verify = `just ("edited" , "world" , "edited" , nothing)` |
| 落盘 | 第二局写成包，import 读回 | verify 相同（包 83 KB） |
| P3 第三局 | 带模式的 λ | 铸了新名字 → 哨兵 → `nothing` |

后端回归：自带 `run-tests.sh` 通过；transport 矩阵 14 项 MATCH，t11/t11b 停在预期残留，t16 与 V2-RESULTS 相同。项目 `check.sh` 全量重查 11 个模块 5 秒，`run.sh` 全部如期。

## 决定

1. ToyCode 脚本第三条 `def 7 []` → `sort 0`：名字是后端按出现先后编的号，7 不对应任何东西；LLM 答 `Type` 时解析出来的正好是 `sort 0`。
2. evalP 用"查 + 跑是 turn 的两步"：调用参数是程序；verify 只要 `VerCfg`。录音对位留给 P5。
3. 白名单守卫 = 子线的 `realm` 运输，不另造机制：只能挡（看不见、写不回），不能添。程序不穿过子线边界：整回合在孩子里做，Spec 只传任务文本——否则 Spec 也得是程序，把不可判定复制一份（第一版就是这么写的，评审指出后改掉）。
4. 键用 ℕ 代替 `Fin n`（Fin 的值带证明项，LLM 难写）；值用 String。
5. LLM 的代码只能引用岗位表里已有的名字；带模式的 λ、where 会铸新定义，判为非代码。铸新种类的键是 S7 `cfgSlot` 的事。
6. 重载字面量在 quote 前求值消掉：LLM 写的 `2`，树里就是 `lit (natL 2)`。
7. `Vis` 加 `ins`（实例参数），对应 Agda 的 `Instance`。

## 坑

- cubical 绑定了 FROMNAT：`2` 不知道类型时被解析成 `fromNat ⦃…⦄ 2`；`inferExpr` 默认 `DontExpandLast`，尾部的实例参数不补，于是查不过。两处都修了。
- `--cubical-run` / `--cubical-drive-then` 的表达式里，open 进来的名字要带前缀（`H.prog`）。
- 规范形按行宽折行：逐字比较整段输出可以，比较单行字符串前要压平空白。
- ToyText 里 `rec` 有歧义（`Empty.rec` 与 `Maybe.rec`），所以给 LLM 一个 `orElse`。
- 驱动器约 800 行（含注释），比原估计的 60 + 40 行多得多：名字表、Level、各种失败路径和日志占了大头。
- 目标编译器只有服务器上的 agda-cubical-run（Agda 2.9.0）+ cubical-0.9，不迁就其它版本。

## 留给后面

- P4：`prompt : Trace → Q llm` 是一个 fold；ToyText 里 `Q llm` 现在是槽 Fp。真 LLM 接在 `cmd:` 上（照 `llm-echo.sh` 的形状写一个适配器）。
- P5：名字表要进包（表进哈希）。现在落盘的包里只有棋谱：verify 不解码树，所以读回来能查；要重查树、跨进程回放，就得有表，否则 `def n` 的 n 是漂的。不可判定只剩子线里 evalP 的调用参数一处：录音对位要么只按工具对位（run 步的回应类型只依赖工具），要么用树的指纹。
- 后端边界：Level 一律补 `lzero`；Raw 不带 relevance / quantity 修饰；Name 只支持 ℕ；消费者要有名字。
