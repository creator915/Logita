#!/bin/sh
# 用新后端 agda-cubical-run 把 ToyStore 里的项算到规范形（先跑 ./check.sh）
# 注意：被 open 的模块里的名字在这里要带前缀，例如 D.board
cd "$(dirname "$0")" || exit 1
export LC_ALL=C.UTF-8
run() { echo "--- $1"; agda -v0 --cubical-run="$1" src/ToyStore.agda; }
run 'theTrace'                                   # §7  真对手跑出的棋谱
run 'finalBoard kx'                              #     终局 x
run 'finalBoard ky'                              #     终局 y
run 'fst inc-tx'                                 #     一步 run 在对象层的事务
run 'fst result′ ky'                             # §11 换运输：叶子只看见 y
run 'moved kx′'                                  # §10 沿 ua 搬运后的数据库
run 'moved ky′'
run 'fst (fst (fst (snd replayed)))'             # §12 回放：脚本一条没消费
run 'length (snd (snd replayed))'                #     回放棋谱长度
run 'D.board (fst (fst (snd diverged))) kx'      #     录音失效后的终局 x
run 'length (snd (snd diverged))'                #     录音 7 条 + 重问 2 条
# ToyCode：LLM 答代码、检查器变成值
runC() { echo "--- ToyCode $1"; agda -v0 --cubical-run="$1" src/ToyCode.agda; }
runC 'theTrace'                                  # §5  棋谱：代码进日志、检查是一步
runC 'fst result kx'                             #     终局 x = 5
runC 'fst (fst (fst (fst (snd replayed))))'      # §6  回放：脚本一条没消费
runC 'RS.resume (H.prog stratRoot 0) theTrace'    # §7  录音喂回程序：停在 done（inr 2）
# ToyText（P3）：文本世界、真工具、白名单
runT() { echo "--- ToyText $1"; agda -v0 --cubical-run="$1" src/ToyText.agda; }
runT 'look (fst result)'                          # §6  终局：0 1 2 5 号（5 号被运输挡住）
runT 'length theTrace'                            #     根这一层 7 步（两条子线各自带着自己的棋谱）
# 驱动器（P2/P3）：后端答 ask——回显 LLM、checkInternal；完整验收见 drive/accept.sh
echo "--- drive ToyCode（回显 2 / 3 / Type）"
agda -v0 --cubical-drive=driven --cubical-oracle=file:drive/toycode.answers --cubical-drive-then=verifyX src/ToyCode.agda 2>/dev/null
echo "--- drive ToyText（回显四个回答）"
agda -v0 --cubical-drive=driven --cubical-oracle=file:drive/toytext.answers --cubical-drive-then=verifyRun src/ToyText.agda 2>/dev/null
