#!/bin/sh
# 外部预言机的最小样子：stdin 收提示词，stdout 交回答（Agda 代码）。
# 真 LLM 的适配器（P4）是同一个形状：把提示词发给模型，把模型写的代码打印出来。
# 这里不调模型：从 $ANSWERS 里按顺序取下一行，提示词追加到 $ANSWERS.prompts 供查看。
ANSWERS=${ANSWERS:?需要 ANSWERS=回答文件}
n=$(cat "$ANSWERS.n" 2>/dev/null || echo 0)
cat >> "$ANSWERS.prompts"
echo "=== ($n)" >> "$ANSWERS.prompts"
grep -v '^#' "$ANSWERS" | grep -v '^[[:space:]]*$' | sed -n "$((n + 1))p"
echo $((n + 1)) > "$ANSWERS.n"
