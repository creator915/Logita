#!/bin/sh
# 驱动器验收（P2、P3）：后端 agda-cubical-run 的 --cubical-drive 跑 ToyCode / ToyText，
# 用回显 LLM（文件或外部命令）作答，逐字对照 Agda 里算出来的结果。
#   ./drive/accept.sh            用 PATH 里的 agda
#   AGDA=/path/to/agda-cubical-run ./drive/accept.sh
cd "$(dirname "$0")/.." || exit 1
export LC_ALL=C.UTF-8
AGDA=${AGDA:-agda}
tmp=$(mktemp -d); trap 'rm -rf "$tmp"' EXIT
fails=0
ok()  { echo "  ✓ $1"; }
bad() { echo "  ✗ $1"; fails=$((fails + 1)); }
flat() { printf '%s' "$1" | tr -s ' \n' '  '; }   # 规范形会按行宽折行：比较前把空白压平
same() { if [ "$(flat "$2")" = "$(flat "$3")" ]; then ok "$1"; else bad "$1"; echo "    得到：$2"; echo "    应为：$3"; fi; }
drive() { # 文件 预言机 消费者 [更多参数]
  f=$1; o=$2; c=$3; shift 3
  "$AGDA" -v0 --cubical-drive=driven --cubical-oracle="$o" --cubical-drive-then="$c" "$@" "src/$f.agda" 2>> "$tmp/drive.log"
}
run() { "$AGDA" -v0 --cubical-run="$2" "src/$1.agda"; }

echo "P2  ToyCode：回显文件 2 / 3 / Type"
same "棋谱与 theTrace 逐字相同" "$(drive ToyCode file:drive/toycode.answers runTrace)" "$(run ToyCode theTrace)"
same "verify 的终局 x = 5" "$(drive ToyCode file:drive/toycode.answers verifyX)" "just (just 5)"
echo 'Type' > "$tmp/bad1"; echo 'true' > "$tmp/bad2"; echo ')(' > "$tmp/bad3"
for b in bad1 bad2 bad3; do
  case "$(drive ToyCode "file:$tmp/$b" runTrace)" in
    *", nothing)"*) ok "坏回答 $(cat "$tmp/$b") → 检查那一步回应 nothing" ;;
    *) bad "坏回答 $(cat "$tmp/$b")" ;;
  esac
done

echo "P3  ToyText：文本世界、真工具、白名单"
same "第一局棋谱与 theTrace 逐字相同" "$(drive ToyText file:drive/toytext.answers runTrace)" "$(run ToyText theTrace)"
same "第一局 verify：0 1 2 5 号" "$(drive ToyText file:drive/toytext.answers verifyRun)" \
     'just (just "input text" ∷ just "world" ∷ just "hello" ∷ nothing ∷ [])'
rm -f drive/toytext-2.answers.n drive/toytext-2.answers.prompts
same "第二局（外部命令、>>= 与 λ、读后写、语法错）" \
     "$(drive ToyText 'cmd:ANSWERS=drive/toytext-2.answers sh drive/llm-echo.sh' verifyRun --cubical-term-file="$tmp/run.term")" \
     'just (just "edited" ∷ just "world" ∷ just "edited" ∷ nothing ∷ [])'
same "第二局落盘的包读回来，verify 相同" \
     "$("$AGDA" -v0 --cubical-import=verifyRun --cubical-term-file="$tmp/run.term" src/ToyText.agda)" \
     'just (just "edited" ∷ just "world" ∷ just "edited" ∷ nothing ∷ [])'
rm -f drive/toytext-2.answers.n drive/toytext-2.answers.prompts
same "第三局（带模式的 λ 铸新名字 → 哨兵）" "$(drive ToyText file:drive/toytext-3.answers verifyRun)" \
     'just (just "input text" ∷ nothing ∷ nothing ∷ nothing ∷ [])'

if [ "$fails" -eq 0 ]; then echo "全部通过"; else echo "$fails 项失败；驱动日志："; cat "$tmp/drive.log"; exit 1; fi
