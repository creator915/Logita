#!/bin/sh
# 检查全部模块：ToyStore 依赖 Game / PathCat / Harness / Store / Replay；
# ToyCode 另依赖 Code / CodeDec / Text；ToyText 是 P3（文本世界上的真工具）
cd "$(dirname "$0")" && LC_ALL=C.UTF-8 agda src/ToyStore.agda && LC_ALL=C.UTF-8 agda src/ToyCode.agda && LC_ALL=C.UTF-8 agda src/ToyText.agda
