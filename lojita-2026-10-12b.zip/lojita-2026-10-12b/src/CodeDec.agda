{-# OPTIONS --safe --cubical #-}
------------------------------------------------------------------------
-- CodeDec.agda —— 机械部分：语法树可判定相等（录音回放、Rules.isSetResult、Store Meta Raw 都要它）
--   每个构造子一个"是不是它"的谓词（不同构造子 ⇒ 不等）和每个参数一个投影（同构造子 ⇒ 逐参数比）。
--   这个文件是按构造子表生成的；改 Raw 的构造子就重新生成，不手改。
------------------------------------------------------------------------
open import Cubical.Foundations.Prelude
open import Cubical.Relation.Nullary
open import Cubical.Relation.Nullary.Properties
open import Cubical.Data.Nat
open import Cubical.Data.Nat.Properties using (discreteℕ ; znots ; snotz ; injSuc)
open import Cubical.Data.Unit
open import Cubical.Data.Empty
open import Cubical.Data.List
open import Cubical.Data.List.Properties using (¬nil≡cons ; ¬cons≡nil ; cons-inj₁ ; cons-inj₂)
open import Cubical.Data.Maybe
open import Cubical.Data.Maybe.Properties using (just-inj)
open import Game
open import Text using (String ; discreteString)

module CodeDec
  (Name : Type) (_≟N_ : Discrete Name)
  (Meta : Type) (_≟M_ : Discrete Meta)
  (WSig : Sig)
  where

open import Code Name Meta WSig

-- 两个小的，手写
tagV : Vis → ℕ                         -- 构造子的序号：序号不同 ⇒ 不等
tagV vis = 0
tagV hid = 1
tagV ins = 2

discreteVis : Discrete Vis
discreteVis vis vis = yes refl
discreteVis hid hid = yes refl
discreteVis ins ins = yes refl
discreteVis vis hid = no (λ p → znots (cong tagV p))
discreteVis vis ins = no (λ p → znots (cong tagV p))
discreteVis hid vis = no (λ p → snotz (cong tagV p))
discreteVis hid ins = no (λ p → znots (injSuc (cong tagV p)))
discreteVis ins vis = no (λ p → snotz (cong tagV p))
discreteVis ins hid = no (λ p → snotz (injSuc (cong tagV p)))

tagL : Lit → ℕ                         -- 构造子的序号：序号不同 ⇒ 不等
tagL (natL _)  = 0
tagL (nameL _) = 1
tagL (strL _)  = 2
natL0 : Lit → Maybe ℕ
natL0 (natL n) = just n
natL0 _ = nothing
nameL0 : Lit → Maybe Name
nameL0 (nameL n) = just n
nameL0 _ = nothing
strL0 : Lit → Maybe String
strL0 (strL s) = just s
strL0 _ = nothing

discreteLit : Discrete Lit
discreteLit (natL n) (natL m) with discreteℕ n m
... | yes p = yes (cong natL p)
... | no ¬p = no (λ q → ¬p (just-inj n m (cong natL0 q)))
discreteLit (nameL n) (nameL m) with n ≟N m
... | yes p = yes (cong nameL p)
... | no ¬p = no (λ q → ¬p (just-inj n m (cong nameL0 q)))
discreteLit (strL s) (strL t) with discreteString s t
... | yes p = yes (cong strL p)
... | no ¬p = no (λ q → ¬p (just-inj s t (cong strL0 q)))
discreteLit (natL _)  (nameL _) = no (λ p → znots (cong tagL p))
discreteLit (natL _)  (strL _)  = no (λ p → znots (cong tagL p))
discreteLit (nameL _) (natL _)  = no (λ p → snotz (cong tagL p))
discreteLit (nameL _) (strL _)  = no (λ p → znots (injSuc (cong tagL p)))
discreteLit (strL _)  (natL _)  = no (λ p → snotz (cong tagL p))
discreteLit (strL _)  (nameL _) = no (λ p → snotz (injSuc (cong tagL p)))

-- 谓词与投影
isvar : Raw → Type
isvar (var _ _) = Unit
isvar _ = ⊥
var0 : Raw → Maybe ℕ
var0 (var i _) = just i
var0 _ = nothing
var1 : Raw → Maybe Elims
var1 (var _ es) = just es
var1 _ = nothing

islam : Raw → Type
islam (lam _ _) = Unit
islam _ = ⊥
lam0 : Raw → Maybe Vis
lam0 (lam v _) = just v
lam0 _ = nothing
lam1 : Raw → Maybe Raw
lam1 (lam _ t) = just t
lam1 _ = nothing

islit : Raw → Type
islit (lit _) = Unit
islit _ = ⊥
lit0 : Raw → Maybe Lit
lit0 (lit l) = just l
lit0 _ = nothing

isdef : Raw → Type
isdef (def _ _) = Unit
isdef _ = ⊥
def0 : Raw → Maybe Name
def0 (def n _) = just n
def0 _ = nothing
def1 : Raw → Maybe Elims
def1 (def _ es) = just es
def1 _ = nothing

iscon : Raw → Type
iscon (con _ _) = Unit
iscon _ = ⊥
con0 : Raw → Maybe Name
con0 (con c _) = just c
con0 _ = nothing
con1 : Raw → Maybe Elims
con1 (con _ es) = just es
con1 _ = nothing

ispi : Raw → Type
ispi (pi _ _ _) = Unit
ispi _ = ⊥
pi0 : Raw → Maybe Vis
pi0 (pi v _ _) = just v
pi0 _ = nothing
pi1 : Raw → Maybe Raw
pi1 (pi _ a _) = just a
pi1 _ = nothing
pi2 : Raw → Maybe Raw
pi2 (pi _ _ b) = just b
pi2 _ = nothing

issort : Raw → Type
issort (sort _) = Unit
issort _ = ⊥
sort0 : Raw → Maybe ℕ
sort0 (sort n) = just n
sort0 _ = nothing

ismeta : Raw → Type
ismeta (meta _ _) = Unit
ismeta _ = ⊥
meta0 : Raw → Maybe Meta
meta0 (meta m _) = just m
meta0 _ = nothing
meta1 : Raw → Maybe Elims
meta1 (meta _ es) = just es
meta1 _ = nothing

isapp : Elim → Type
isapp (app _ _) = Unit
isapp _ = ⊥
app0 : Elim → Maybe Vis
app0 (app v _) = just v
app0 _ = nothing
app1 : Elim → Maybe Raw
app1 (app _ t) = just t
app1 _ = nothing

isproj : Elim → Type
isproj (proj _) = Unit
isproj _ = ⊥
proj0 : Elim → Maybe Name
proj0 (proj f) = just f
proj0 _ = nothing

ispth : Elim → Type
ispth (pth _ _ _) = Unit
ispth _ = ⊥
pth0 : Elim → Maybe Raw
pth0 (pth x _ _) = just x
pth0 _ = nothing
pth1 : Elim → Maybe Raw
pth1 (pth _ y _) = just y
pth1 _ = nothing
pth2 : Elim → Maybe Raw
pth2 (pth _ _ r) = just r
pth2 _ = nothing

-- 三个互递归的判定
discreteRaw   : Discrete Raw
discreteElim  : Discrete Elim
discreteElims : Discrete Elims

discreteRaw (var i₁ es₁) (var i₂ es₂) with discreteℕ i₁ i₂ | discreteElims es₁ es₂
... | yes p0 | yes p1 = yes (λ j → var (p0 j) (p1 j))
... | no ¬p | _ = no (λ q → ¬p (just-inj i₁ i₂ (cong var0 q)))
... | yes _ | no ¬p = no (λ q → ¬p (just-inj es₁ es₂ (cong var1 q)))
discreteRaw (var i₁ es₁) (lam v₂ t₂) = no (λ p → subst isvar p tt)
discreteRaw (var i₁ es₁) (lit l₂) = no (λ p → subst isvar p tt)
discreteRaw (var i₁ es₁) (def n₂ es₂) = no (λ p → subst isvar p tt)
discreteRaw (var i₁ es₁) (con c₂ es₂) = no (λ p → subst isvar p tt)
discreteRaw (var i₁ es₁) (pi v₂ a₂ b₂) = no (λ p → subst isvar p tt)
discreteRaw (var i₁ es₁) (sort n₂) = no (λ p → subst isvar p tt)
discreteRaw (var i₁ es₁) (meta m₂ es₂) = no (λ p → subst isvar p tt)
discreteRaw (lam v₁ t₁) (var i₂ es₂) = no (λ p → subst islam p tt)
discreteRaw (lam v₁ t₁) (lam v₂ t₂) with discreteVis v₁ v₂ | discreteRaw t₁ t₂
... | yes p0 | yes p1 = yes (λ j → lam (p0 j) (p1 j))
... | no ¬p | _ = no (λ q → ¬p (just-inj v₁ v₂ (cong lam0 q)))
... | yes _ | no ¬p = no (λ q → ¬p (just-inj t₁ t₂ (cong lam1 q)))
discreteRaw (lam v₁ t₁) (lit l₂) = no (λ p → subst islam p tt)
discreteRaw (lam v₁ t₁) (def n₂ es₂) = no (λ p → subst islam p tt)
discreteRaw (lam v₁ t₁) (con c₂ es₂) = no (λ p → subst islam p tt)
discreteRaw (lam v₁ t₁) (pi v₂ a₂ b₂) = no (λ p → subst islam p tt)
discreteRaw (lam v₁ t₁) (sort n₂) = no (λ p → subst islam p tt)
discreteRaw (lam v₁ t₁) (meta m₂ es₂) = no (λ p → subst islam p tt)
discreteRaw (lit l₁) (var i₂ es₂) = no (λ p → subst islit p tt)
discreteRaw (lit l₁) (lam v₂ t₂) = no (λ p → subst islit p tt)
discreteRaw (lit l₁) (lit l₂) with discreteLit l₁ l₂
... | yes p0 = yes (λ j → lit (p0 j))
... | no ¬p = no (λ q → ¬p (just-inj l₁ l₂ (cong lit0 q)))
discreteRaw (lit l₁) (def n₂ es₂) = no (λ p → subst islit p tt)
discreteRaw (lit l₁) (con c₂ es₂) = no (λ p → subst islit p tt)
discreteRaw (lit l₁) (pi v₂ a₂ b₂) = no (λ p → subst islit p tt)
discreteRaw (lit l₁) (sort n₂) = no (λ p → subst islit p tt)
discreteRaw (lit l₁) (meta m₂ es₂) = no (λ p → subst islit p tt)
discreteRaw (def n₁ es₁) (var i₂ es₂) = no (λ p → subst isdef p tt)
discreteRaw (def n₁ es₁) (lam v₂ t₂) = no (λ p → subst isdef p tt)
discreteRaw (def n₁ es₁) (lit l₂) = no (λ p → subst isdef p tt)
discreteRaw (def n₁ es₁) (def n₂ es₂) with _≟N_ n₁ n₂ | discreteElims es₁ es₂
... | yes p0 | yes p1 = yes (λ j → def (p0 j) (p1 j))
... | no ¬p | _ = no (λ q → ¬p (just-inj n₁ n₂ (cong def0 q)))
... | yes _ | no ¬p = no (λ q → ¬p (just-inj es₁ es₂ (cong def1 q)))
discreteRaw (def n₁ es₁) (con c₂ es₂) = no (λ p → subst isdef p tt)
discreteRaw (def n₁ es₁) (pi v₂ a₂ b₂) = no (λ p → subst isdef p tt)
discreteRaw (def n₁ es₁) (sort n₂) = no (λ p → subst isdef p tt)
discreteRaw (def n₁ es₁) (meta m₂ es₂) = no (λ p → subst isdef p tt)
discreteRaw (con c₁ es₁) (var i₂ es₂) = no (λ p → subst iscon p tt)
discreteRaw (con c₁ es₁) (lam v₂ t₂) = no (λ p → subst iscon p tt)
discreteRaw (con c₁ es₁) (lit l₂) = no (λ p → subst iscon p tt)
discreteRaw (con c₁ es₁) (def n₂ es₂) = no (λ p → subst iscon p tt)
discreteRaw (con c₁ es₁) (con c₂ es₂) with _≟N_ c₁ c₂ | discreteElims es₁ es₂
... | yes p0 | yes p1 = yes (λ j → con (p0 j) (p1 j))
... | no ¬p | _ = no (λ q → ¬p (just-inj c₁ c₂ (cong con0 q)))
... | yes _ | no ¬p = no (λ q → ¬p (just-inj es₁ es₂ (cong con1 q)))
discreteRaw (con c₁ es₁) (pi v₂ a₂ b₂) = no (λ p → subst iscon p tt)
discreteRaw (con c₁ es₁) (sort n₂) = no (λ p → subst iscon p tt)
discreteRaw (con c₁ es₁) (meta m₂ es₂) = no (λ p → subst iscon p tt)
discreteRaw (pi v₁ a₁ b₁) (var i₂ es₂) = no (λ p → subst ispi p tt)
discreteRaw (pi v₁ a₁ b₁) (lam v₂ t₂) = no (λ p → subst ispi p tt)
discreteRaw (pi v₁ a₁ b₁) (lit l₂) = no (λ p → subst ispi p tt)
discreteRaw (pi v₁ a₁ b₁) (def n₂ es₂) = no (λ p → subst ispi p tt)
discreteRaw (pi v₁ a₁ b₁) (con c₂ es₂) = no (λ p → subst ispi p tt)
discreteRaw (pi v₁ a₁ b₁) (pi v₂ a₂ b₂) with discreteVis v₁ v₂ | discreteRaw a₁ a₂ | discreteRaw b₁ b₂
... | yes p0 | yes p1 | yes p2 = yes (λ j → pi (p0 j) (p1 j) (p2 j))
... | no ¬p | _ | _ = no (λ q → ¬p (just-inj v₁ v₂ (cong pi0 q)))
... | yes _ | no ¬p | _ = no (λ q → ¬p (just-inj a₁ a₂ (cong pi1 q)))
... | yes _ | yes _ | no ¬p = no (λ q → ¬p (just-inj b₁ b₂ (cong pi2 q)))
discreteRaw (pi v₁ a₁ b₁) (sort n₂) = no (λ p → subst ispi p tt)
discreteRaw (pi v₁ a₁ b₁) (meta m₂ es₂) = no (λ p → subst ispi p tt)
discreteRaw (sort n₁) (var i₂ es₂) = no (λ p → subst issort p tt)
discreteRaw (sort n₁) (lam v₂ t₂) = no (λ p → subst issort p tt)
discreteRaw (sort n₁) (lit l₂) = no (λ p → subst issort p tt)
discreteRaw (sort n₁) (def n₂ es₂) = no (λ p → subst issort p tt)
discreteRaw (sort n₁) (con c₂ es₂) = no (λ p → subst issort p tt)
discreteRaw (sort n₁) (pi v₂ a₂ b₂) = no (λ p → subst issort p tt)
discreteRaw (sort n₁) (sort n₂) with discreteℕ n₁ n₂
... | yes p0 = yes (λ j → sort (p0 j))
... | no ¬p = no (λ q → ¬p (just-inj n₁ n₂ (cong sort0 q)))
discreteRaw (sort n₁) (meta m₂ es₂) = no (λ p → subst issort p tt)
discreteRaw (meta m₁ es₁) (var i₂ es₂) = no (λ p → subst ismeta p tt)
discreteRaw (meta m₁ es₁) (lam v₂ t₂) = no (λ p → subst ismeta p tt)
discreteRaw (meta m₁ es₁) (lit l₂) = no (λ p → subst ismeta p tt)
discreteRaw (meta m₁ es₁) (def n₂ es₂) = no (λ p → subst ismeta p tt)
discreteRaw (meta m₁ es₁) (con c₂ es₂) = no (λ p → subst ismeta p tt)
discreteRaw (meta m₁ es₁) (pi v₂ a₂ b₂) = no (λ p → subst ismeta p tt)
discreteRaw (meta m₁ es₁) (sort n₂) = no (λ p → subst ismeta p tt)
discreteRaw (meta m₁ es₁) (meta m₂ es₂) with _≟M_ m₁ m₂ | discreteElims es₁ es₂
... | yes p0 | yes p1 = yes (λ j → meta (p0 j) (p1 j))
... | no ¬p | _ = no (λ q → ¬p (just-inj m₁ m₂ (cong meta0 q)))
... | yes _ | no ¬p = no (λ q → ¬p (just-inj es₁ es₂ (cong meta1 q)))

discreteElim (app v₁ t₁) (app v₂ t₂) with discreteVis v₁ v₂ | discreteRaw t₁ t₂
... | yes p0 | yes p1 = yes (λ j → app (p0 j) (p1 j))
... | no ¬p | _ = no (λ q → ¬p (just-inj v₁ v₂ (cong app0 q)))
... | yes _ | no ¬p = no (λ q → ¬p (just-inj t₁ t₂ (cong app1 q)))
discreteElim (app v₁ t₁) (proj f₂) = no (λ p → subst isapp p tt)
discreteElim (app v₁ t₁) (pth x₂ y₂ r₂) = no (λ p → subst isapp p tt)
discreteElim (proj f₁) (app v₂ t₂) = no (λ p → subst isproj p tt)
discreteElim (proj f₁) (proj f₂) with _≟N_ f₁ f₂
... | yes p0 = yes (λ j → proj (p0 j))
... | no ¬p = no (λ q → ¬p (just-inj f₁ f₂ (cong proj0 q)))
discreteElim (proj f₁) (pth x₂ y₂ r₂) = no (λ p → subst isproj p tt)
discreteElim (pth x₁ y₁ r₁) (app v₂ t₂) = no (λ p → subst ispth p tt)
discreteElim (pth x₁ y₁ r₁) (proj f₂) = no (λ p → subst ispth p tt)
discreteElim (pth x₁ y₁ r₁) (pth x₂ y₂ r₂) with discreteRaw x₁ x₂ | discreteRaw y₁ y₂ | discreteRaw r₁ r₂
... | yes p0 | yes p1 | yes p2 = yes (λ j → pth (p0 j) (p1 j) (p2 j))
... | no ¬p | _ | _ = no (λ q → ¬p (just-inj x₁ x₂ (cong pth0 q)))
... | yes _ | no ¬p | _ = no (λ q → ¬p (just-inj y₁ y₂ (cong pth1 q)))
... | yes _ | yes _ | no ¬p = no (λ q → ¬p (just-inj r₁ r₂ (cong pth2 q)))

discreteElims []       []       = yes refl
discreteElims []       (_ ∷ _)  = no ¬nil≡cons
discreteElims (_ ∷ _)  []       = no ¬cons≡nil
discreteElims (e ∷ es) (f ∷ fs) with discreteElim e f | discreteElims es fs
... | yes p | yes q = yes (λ j → p j ∷ q j)
... | no ¬p | _     = no (λ r → ¬p (cons-inj₁ r))
... | yes _ | no ¬q = no (λ r → ¬q (cons-inj₂ r))

isSetRaw : isSet Raw
isSetRaw = Discrete→isSet discreteRaw
