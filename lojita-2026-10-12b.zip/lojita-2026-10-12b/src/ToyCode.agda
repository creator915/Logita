{-# OPTIONS --safe --cubical #-}
------------------------------------------------------------------------
-- ToyCode.agda —— LLM 答代码（数据），检查器把它变成值（控制），程序用它走一步；再对着录音回放
--   预言机 = 脚本 LLM ⊎ 检查器（一个槽 natSlot，码 = nat）
--   检查器的玩具替身是一张表（只认数的字面量）——真跑时这个参数换成后端 checkInternal
--   §5 跑一局：棋谱里 LLM 的回答是语法树，检查那一步的回应是 Maybe ℕ；终局由 refl 算出
--   §6 回放：可判定相等只比指纹 natSlot 和树（CodeDec.discreteRaw），棋谱逐字相同、脚本一条没消费
--   §7 状态 = 棋谱的 fold（P1）：录音喂回程序，回到 done
--   §8 驱动器（P2）：同一个程序，ask 交出去（后端来答）；在 Agda 里拿脚本当余模型，棋谱与 §5 逐字相同
------------------------------------------------------------------------
module ToyCode where

open import Cubical.Foundations.Prelude
open import Cubical.Relation.Nullary
open import Cubical.Data.Nat
open import Cubical.Data.Nat.Properties using (discreteℕ ; isSetℕ)
open import Cubical.Data.Maybe
open import Cubical.Data.Sigma
open import Cubical.Data.Sum
open import Cubical.Data.Unit
open import Cubical.Data.Empty
open import Cubical.Data.List
open import Game

------------------------------------------------------------------------
-- 1 schema：一个键，装上数据库
------------------------------------------------------------------------
data Key : Type where
  kx : Key

_≟K_ : Discrete Key
kx ≟K kx = yes refl

import Store
module DB = Store Key ℕ _≟K_ discreteℕ
open DB

------------------------------------------------------------------------
-- 2 代码：名字与洞的类型在玩具里都取 ℕ；世界签名 = 数据库的
------------------------------------------------------------------------
import Code
module C = Code ℕ ℕ WSig
open C

import CodeDec
module CD = CodeDec ℕ discreteℕ ℕ discreteℕ WSig
open CD using (discreteRaw)

------------------------------------------------------------------------
-- 3 预言机：脚本 LLM（问 Unit，答一棵树）⊎ 检查器（一个槽）
------------------------------------------------------------------------
data Slot : Type where
  natSlot : Slot

codeOf : Slot → U
codeOf natSlot = nat

decSlot : Discrete Slot
decSlot natSlot natSlot = yes refl

module CK = Checker Unit (λ _ → Unit) (λ _ → Raw) Slot codeOf
open CK

llmF : List Raw → (o : Unit) → Unit → Raw × List Raw     -- 脚本 LLM；脚本空了就答一个过不了检查的树
llmF []       _ _ = sort 0 , []
llmF (r ∷ rs) _ _ = r , rs

chkT : Unit → (f : Slot) → Raw → Maybe (El (codeOf f)) × Unit   -- 检查器的玩具替身：只认数的字面量
chkT _ natSlot (lit (natL n)) = just n , tt
chkT _ natSlot _              = nothing , tt

module OD = Dyn {List Raw} {Unit} llmF chkT
open OD

------------------------------------------------------------------------
-- 4 装上 Harness；一个工具 incX；配置树只有根
------------------------------------------------------------------------
import Harness
module H = Harness Oracle Q A OState oracle WSig Board isSetBoard isSetWRes world ℕ ℕ Lifting restrictL mergeL
open H

rd : Key → Free WSig (Maybe ℕ)
rd k = move (get k) done

wr : Key → ℕ → Free WSig Unit
wr k v = move (set k v) done

val : Maybe ℕ → ℕ
val nothing  = 0
val (just n) = n

data RTool : Type where
  incX : RTool

Rroot : Rules
Rroot = record { Tool = RTool ; Call = λ _ → ℕ ; Result = λ _ → ℕ ; isSetResult = λ _ → isSetℕ
               ; impl = λ { incX n → rd kx >>= λ mx → let nx = val mx + n in wr kx nx >>= λ _ → done nx } }

root : Config
root = node Rroot ⊥ (λ ()) (λ ())

-- 一回合 = Reflect.turn 的实例：问 LLM 要代码（r : Raw，数据）→ check 自己再走一步：交给检查器
-- （反射：回应是 Maybe ℕ；续体就是"下一拍"）→ 通过就 run incX n，不通过就停
module RF = Reflect (inl tt)

checkC : RF.Check root
checkC _ r = move (ask (inr natSlot) r) λ mn → done (map-Maybe (run incX) mn)

budget : ℕ → List Unit
budget zero    = []
budget (suc n) = tt ∷ budget n

stratRoot : Strat root
stratRoot = record { prog = λ _ → RF.rounds root checkC (budget 8) ; kids = λ () }

------------------------------------------------------------------------
-- 5 跑一局
------------------------------------------------------------------------
module D = Dynamics Unit (λ x _ → x) (λ x _ → x) playExec
open D

script : List Raw                                 -- 两个数，再一个过不了检查的树
script = lit (natL 2) ∷ lit (natL 3) ∷ sort 0 ∷ []   -- sort 0：LLM 答 Type 时后端解析出来的就是它

b0 : Board
b0 = λ _ → nothing

w0 : W
w0 = (script , tt) , b0 , tt

result : Position root b0
result = finish root stratRoot (prog stratRoot 0) w0

theTrace : Trace (Sig-of root)
theTrace = fst (snd result)

final-x : fst result kx ≡ just 5
final-x = refl

-- 棋谱：代码进日志、检查是一步、值被用掉
trace-is : theTrace ≡ (ask (inl tt) tt , lit (natL 2)) ∷ (ask (inr natSlot) (lit (natL 2)) , just 2) ∷ (run incX 2 , 2)
                    ∷ (ask (inl tt) tt , lit (natL 3)) ∷ (ask (inr natSlot) (lit (natL 3)) , just 3) ∷ (run incX 3 , 5)
                    ∷ (ask (inl tt) tt , sort 0)       ∷ (ask (inr natSlot) (sort 0) , nothing)
                    ∷ []
trace-is = refl

------------------------------------------------------------------------
-- 6 回放：先拼可判定相等（指纹 + 树），再放录音
------------------------------------------------------------------------
import Replay
module RP = Replay Oracle Q A OState oracle WSig Board isSetBoard isSetWRes world ℕ ℕ Lifting restrictL mergeL
open RP using (DecCfg ; wrap ; dynLens)
module DA = RP.DecAct (decOracle (λ _ _ → yes refl) decSlot) (decQ (λ _ _ _ → yes refl) discreteRaw) discreteℕ

decRoot : DecCfg root
decRoot = record
  { decOp  = DA.decAct Rroot ⊥ (λ { incX incX → yes refl }) (λ _ → discreteℕ) (λ ())
  ; decRes = λ _ → discreteℕ
  ; kids   = λ () }

recorder : Comodel (Sig-of root) (W × Trace (Sig-of root))
recorder = wrap root decRoot (opp root stratRoot) (dynLens Unit)

replayed : ℕ × (W × Trace (Sig-of root)) × Trace (Sig-of root)
replayed = Play.play recorder (prog stratRoot 0) (w0 , theTrace)

replay-trace : snd (snd replayed) ≡ theTrace                  -- 棋谱逐字相同
replay-trace = refl

replay-untouched : fst (fst (fst (fst (snd replayed)))) ≡ script   -- 脚本一条没消费
replay-untouched = refl

------------------------------------------------------------------------
-- 7 状态 = 棋谱的 fold（P1）：整条录音喂回程序，停在 done（走成 2 回合）
------------------------------------------------------------------------
module RS = Resume {Sig-of root} (RP.decOp decRoot)

resume-done : RS.resume (prog stratRoot 0) theTrace ≡ inr 2
resume-done = refl

next-1 : RS.next (prog stratRoot 0) (take 1 theTrace) ≡ just (ask (inr natSlot) (lit (natL 2)))
next-1 = refl

------------------------------------------------------------------------
-- 8 驱动器（P2）
--   driven：同一个程序，ask 那一步交出去，run 在 Agda 里算。后端（--cubical-drive=driven）来答 ask：
--   (inl tt , tt) 问 LLM，(inr natSlot , r) 交给 checkInternal。
--   在 Agda 里拿预言机本身（oracleC：脚本 LLM + 表检查器）当余模型跑它，棋谱与 §5 逐字相同。
------------------------------------------------------------------------
module DR = Drive Unit (λ x _ → x) (λ x _ → x)

driven : Free OSig (ℕ × DR.WD × Trace (Sig-of root))
driven = DR.drive root stratRoot (prog stratRoot 0) (b0 , tt)

driven-trace : snd (snd (fst (Play.play oracleC driven (script , tt)))) ≡ theTrace
driven-trace = refl

driven-agrees : Play.play (opp root stratRoot) (prog stratRoot 0) w0
              ≡ DR.shape (Play.play oracleC driven (script , tt))
driven-agrees = DR.drive-agrees root stratRoot (prog stratRoot 0) (script , tt) b0 tt

-- 后端跑完，把结果交给它们看（--cubical-drive-then=…）
runTrace : ℕ × DR.WD × Trace (Sig-of root) → Trace (Sig-of root)
runTrace e = snd (snd e)

-- verify 的终局里 x 的值：just (just 5) = 录音合法、终局 x = 5
verifyX : ℕ × DR.WD × Trace (Sig-of root) → Maybe (Maybe ℕ)
verifyX e = map-Maybe (λ b → b kx) (RP.verify root (RP.ver root decRoot) b0 (snd (snd e)))

verifyX-here : verifyX (fst (Play.play oracleC driven (script , tt))) ≡ just (just 5)
verifyX-here = refl
