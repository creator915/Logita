{-# OPTIONS --safe --cubical #-}
------------------------------------------------------------------------
-- Code.agda —— 代码的类型：上一拍是数据，这一拍是控制
--   §1 语法树 Raw    照 Agda 自己的 Term 画：变量 / λ / 字面量 / 名字 / 构造子 / Π / 宇宙 / 洞，头后面跟消去谱
--   §2 宇宙 U, El    归纳–递归：码 → 类型。码能描述依赖对、依赖函数、对世界的程序、代码本身
--   §3 反射点        检查器是预言机的一员：问题 = 一棵 Raw，回答 = Maybe (El (codeOf f))。
--                    动态是参数：真跑时是后端 checkInternal（机外，归约到这一步时查、把值喂给续体），
--                    玩具里是一张表。不在 Agda 里重造检查器。"下一拍" = 这一步的续体 k。
--   §4 工具表        工具 = (参数的码, 结果的码, 体)；Call / Result 由 El 算出
--   §5 编辑器        洞表 = Store Meta Raw；zonk 把洞表代进树
-- 没有公理：Name、Meta、WSig 都是参数。
------------------------------------------------------------------------
open import Cubical.Foundations.Prelude
open import Cubical.Relation.Nullary
open import Cubical.Data.Nat
open import Cubical.Data.Bool.Base
open import Cubical.Data.Unit
open import Cubical.Data.Sigma
open import Cubical.Data.Sum
open import Cubical.Data.Sum.Properties using (discrete⊎)
open import Cubical.Data.List
open import Cubical.Data.Maybe
open import Game
open import Text using (String)

module Code
  (Name : Type)        -- 岗位表 Σ 的键：def / con / proj 引用的是键（角色），不是实例
  (Meta : Type)        -- 洞的名字（实例，运行时铸造，永不复用）
  (WSig : Sig)         -- 世界的签名：工具的体 = Free WSig 里的程序
  where

------------------------------------------------------------------------
-- §1 语法树：照 Agda.Syntax.Internal.Term 画
--   Term：Var i es | Lam (Abs t) | Lit l | Def f es | Con c es | Pi A B | Sort s | MetaV m es
--   Elim：Apply (Arg t) | Proj f | IApply x y r
--   去掉的：绑定变量的显示名（放元数据表，不进相等）、Level 项（并进 Sort ℕ）、DontCare / Dummy（内部用）
--   变量用 de Bruijn 下标：α-等价 = 相等，所以可判定相等有意义（CodeDec.agda）
------------------------------------------------------------------------
data Vis : Type where                  -- 参数可见性：显式 (x : A) / 隐式 {x : A} / 实例 ⦃ x : A ⦄
  vis hid ins : Vis

data Lit : Type where                  -- 字面量：数、名字、串（Agda 的 LitNat / LitQName / LitString）
  natL  : ℕ → Lit
  nameL : Name → Lit
  strL  : String → Lit                 -- 世界的值是文本（ToyText）：LLM 写 "…" 就落在这里

data Raw  : Type
data Elim : Type

Elims : Type                           -- 消去谱：头后面从左到右的一串消去
Elims = List Elim

data Raw where
  var  : ℕ → Elims → Raw               -- Var   第 i 个绑定变量，后接消去谱
  lam  : Vis → Raw → Raw               -- Lam   体内 0 号变量是新绑定的
  lit  : Lit → Raw                     -- Lit
  def  : Name → Elims → Raw            -- Def   岗位表里的名字（键）
  con  : Name → Elims → Raw            -- Con   构造子（也是键）
  pi   : Vis → Raw → Raw → Raw         -- Pi    (x : A) → B；B 里 0 号变量是 x
  sort : ℕ → Raw                       -- Sort  Type n
  meta : Meta → Elims → Raw            -- MetaV 洞："下一拍才有"在语法里的样子（§5）

data Elim where
  app  : Vis → Raw → Elim              -- Apply  喂一个参数
  proj : Name → Elim                   -- Proj   取一个字段（字段名也是键）
  pth  : Raw → Raw → Raw → Elim        -- IApply 路径在 r 处取值，x y 是两端（cubical：ua、transport）

------------------------------------------------------------------------
-- §2 宇宙：归纳–递归
--   为什么必须 IR：工具表、Sig、Step 全是依赖对——第二项的类型由第一项的值决定；
--   要让码说得出这种类型，π / σ 的第二个参数必须是 El a → U：码的构造子引用 El。
--   它的用处是给后端一个可计算的目标类型：归约 El u，再对树跑 checkInternal。
--   为什么没有 univ : U, El univ = ▷ U（宇宙含自己的下一拍）：--safe 下 Agda 拒绝（正性，已实测）；
--   那是 guarded 类型论的权利，要 --guarded 并 postulate dfix。--safe 下"宇宙里有自己"的正确形式
--   是 code : U, El code = Raw——含自己的语法，不含自己的语义；语义靠反射点升一层。
------------------------------------------------------------------------
data U : Type
El : U → Type

data U where
  nat unit bool : U
  name          : U                         -- 键的类型：代码可以指名岗位
  text          : U                         -- 文本（世界的值）
  π σ           : (a : U) → (El a → U) → U  -- ← IR 在这
  _≡ᵘ_          : {a : U} → El a → El a → U -- 等式：证明也是能写的东西（交换性证书、见证）
  list maybe    : U → U
  program          : U → U                     -- 对世界的程序 Free WSig (El a)：工具的体
  code          : U                         -- 语法树本身是一个类型：代码是值（物化的落点）
  later         : U → U                     -- 下一拍的值。El 先用最弱的延迟（thunk）占位；真正的拍由后端的归约给

El nat        = ℕ
El unit       = Unit
El bool       = Bool
El name       = Name
El text       = String
El (π a b)    = (x : El a) → El (b x)
El (σ a b)    = Σ[ x ∈ El a ] El (b x)
El (x ≡ᵘ y)   = x ≡ y
El (list a)   = List (El a)
El (maybe a)  = Maybe (El a)
El (program a)   = Free WSig (El a)
El code       = Raw
El (later a)  = Unit → El a

------------------------------------------------------------------------
-- §3 反射点：检查器是预言机的一员
--   Fp：要查的"角色"的索引（工具槽、证书种类……），可判定；codeOf 给出它的码。
--   接到 Harness：Oracle / Q / A / OState / oracle 五个参数由这里给出，Act 一个字不改。
--   okOf (ask …) = 棋盘不动：检查不碰 Store ✓。回放对位只比指纹 f 和树 r，不比 codeOf f（备选 A）。
--   Σ 哈希不在这里：它在后端的包格式里（哈希不等就拒绝），Rebuilder 要的"前提变了没"由它回答。
------------------------------------------------------------------------
module Checker (Oracle₀ : Type) (Q₀ : Oracle₀ → Type) (A₀ : Oracle₀ → Type)
               (Fp : Type) (codeOf : Fp → U) where

  Oracle : Type
  Oracle = Oracle₀ ⊎ Fp                      -- 原有的预言机 + 每个指纹一个检查器

  Q : Oracle → Type
  Q (inl o) = Q₀ o
  Q (inr f) = Raw                            -- 问题 = 一棵树（这一拍的数据）

  A : Oracle → Type
  A (inl o) = A₀ o
  A (inr f) = Maybe (El (codeOf f))          -- 回答 = 通过就是值（下一拍的控制），不通过 nothing

  -- 动态：原有预言机和检查器并起来。SC 是检查器的状态（装 Σ）；真跑时 chk 是后端，玩具里是一张表
  module Dyn {S₀ SC : Type}
             (oracle₀ : S₀ → (o : Oracle₀) → Q₀ o → A₀ o × S₀)
             (chk     : SC → (f : Fp) → Raw → Maybe (El (codeOf f)) × SC) where

    OState : Type
    OState = S₀ × SC

    oracle : OState → (o : Oracle) → Q o → A o × OState
    oracle (s , c) (inl o) q = let e = oracle₀ s o q in fst e , (snd e , c)
    oracle (s , c) (inr f) r = let e = chk c f r     in fst e , (s , snd e)

  -- 可判定相等只看指纹，不看码
  decOracle : Discrete Oracle₀ → Discrete Fp → Discrete Oracle
  decOracle = discrete⊎

  decQ : (∀ o → Discrete (Q₀ o)) → Discrete Raw → ∀ o → Discrete (Q o)
  decQ d₀ dR (inl o) = d₀ o
  decQ d₀ dR (inr f) = dR

------------------------------------------------------------------------
-- §4 工具表：IR 的兑现
--   一条工具 = 参数的码、结果的码、体。Call / Result 由 El 算出，刚好是 Harness.Rules 要的四样。
--   "LLM 写一个新工具" = 问检查器 (inr t)，codeOf t = π callU (λ _ → program resU)，回答就是体。
--   让新工具真的进配置树要把配置写成数据（S7）；这里只给表的形状。
------------------------------------------------------------------------
record ToolEntry : Type where
  field
    callU resU : U
    isSetRes   : isSet (El resU)                   -- 结果是集合：才能比、才能录音
    body       : El (π callU (λ _ → program resU))    -- = El callU → Free WSig (El resU)
open ToolEntry public

module Tools (Tool : Type) (tab : Tool → ToolEntry) where
  Call Result : Tool → Type
  Call   t = El (callU (tab t))
  Result t = El (resU (tab t))
  isSetResult : ∀ t → isSet (Result t)
  isSetResult t = isSetRes (tab t)
  impl : (t : Tool) → Call t → Free WSig (Result t)
  impl t = body (tab t)

------------------------------------------------------------------------
-- §5 编辑器的对象层：洞表 = Store Meta Raw
--   填洞 = set m r；重填 = 后写赢（upd-same）；撤销 = 写回旧值（补偿）；不同的洞可换 = fill-indep，一个字不用证。
--   岗位表 Σ（def 查的那张）同样是一个 Store：键 = Name，值 = (类型的 Raw, 体的 Raw)。
------------------------------------------------------------------------
Holes : Type                              -- Store Meta Raw 的 Board
Holes = Meta → Maybe Raw

zonk  : Holes → Raw → Raw                 -- 把已填的洞代进树里（Agda 的 instantiateFull）
zonkE : Holes → Elim → Elim
zonks : Holes → Elims → Elims

zonk θ (var i es)  = var i (zonks θ es)
zonk θ (lam v t)   = lam v (zonk θ t)
zonk θ (lit l)     = lit l
zonk θ (def n es)  = def n (zonks θ es)
zonk θ (con c es)  = con c (zonks θ es)
zonk θ (pi v a b)  = pi v (zonk θ a) (zonk θ b)
zonk θ (sort n)    = sort n
zonk θ (meta m [])  with θ m
... | nothing = meta m []                 -- 还没填：洞留着
... | just t  = t                         -- 填了：换成树
zonk θ (meta m (e ∷ es)) = meta m (zonks θ (e ∷ es))   -- 带谱的洞：代入要 β（Agda 的 apply），留给后端

zonkE θ (app v t)    = app v (zonk θ t)
zonkE θ (proj f)     = proj f
zonkE θ (pth x y r)  = pth (zonk θ x) (zonk θ y) (zonk θ r)

zonks θ []       = []
zonks θ (e ∷ es) = zonkE θ e ∷ zonks θ es
