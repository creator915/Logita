{-# OPTIONS --safe --cubical #-}
------------------------------------------------------------------------
-- Game.agda —— 一局棋的三件套
--   规则（签名 Sig）   程序（自由模型 Free = 策略）   对手（余模型 Comodel）
--   棋谱的类型由签名导出；"跑一局" = 策略对上对手。
--   §末（S1）状态 = 棋谱的 fold：resume 把录音喂给程序，next 读出"下一步是什么"。
-- 没有全局公理：所有未知量都是记录字段或模块参数。
------------------------------------------------------------------------
module Game where

open import Cubical.Foundations.Prelude
open import Cubical.Relation.Nullary
open import Cubical.Relation.Nullary.Properties using (Discrete→isSet)
open import Cubical.Data.Nat using (ℕ ; zero ; suc)
open import Cubical.Data.Sigma
open import Cubical.Data.Sum using (_⊎_ ; inl ; inr)
open import Cubical.Data.Maybe using (Maybe ; nothing ; just)
open import Cubical.Data.Empty renaming (rec to ⊥rec)
open import Cubical.Data.List

-- 签名 = 规则书的内容
--   Op      能走的步（已含参数：问什么、调什么）
--   Res o   走了 o 之后能收到的回应
record Sig : Type₁ where
  field
    Op  : Type
    Res : Op → Type
open Sig public

-- 程序 = 自由模型里的项 = 策略
--   done a    交出结果 a
--   move o k  走一步 o；k 说明收到每种回应之后接着怎么走
-- 它是有限的树：每条路都走到 done。停机由形状保证；续命 = 再开一局。
data Free (S : Sig) (A : Type) : Type where
  done : A → Free S A
  move : (o : Op S) → (Res S o → Free S A) → Free S A

-- 程序接程序（单子的 bind；三条律留给 S0）
_>>=_ : {S : Sig} {A B : Type} → Free S A → (A → Free S B) → Free S B
done a   >>= f = f a
move o k >>= f = move o (λ r → k r >>= f)

-- 一步的记录 = (走了什么 , 收到什么)；棋谱 = 一列记录
-- 类型完全由签名决定：签名定了，日志的文法就定了
Step : Sig → Type
Step S = Σ[ o ∈ Op S ] Res S o

Trace : Sig → Type
Trace S = List (Step S)

-- 对手 = 余模型。W = 对手的内部状态（LLM 的记忆、世界的数据库……），写在类型里
--   resp w o  对第 o 步作答，并给出自己的新状态
record Comodel (S : Sig) (W : Type) : Type₁ where
  field
    resp : W → (o : Op S) → Res S o × W
open Comodel public

-- 跑一局：策略对上对手
--   结果 = (策略交出的东西 , 对手的新状态 , 棋谱)
module Play {S : Sig} {W : Type} (C : Comodel S W) where
  play : {A : Type} → Free S A → W → A × W × Trace S
  play (done a)   w = a , w , []
  play (move o k) w =
    let r    = fst (resp C w o)          -- 对手的回应
        w′   = snd (resp C w o)          -- 对手的新状态
        rest = play (k r) w′             -- 接着走
    in fst rest , fst (snd rest) , ((o , r) ∷ snd (snd rest))

-- 程序的结果换个样子（棋谱不变）
mapF : {S : Sig} {A B : Type} → (A → B) → Free S A → Free S B
mapF g (done a)   = done (g a)
mapF g (move o k) = move o (λ r → mapF g (k r))

-- 一局的产出前面添一步
cons1 : {S : Sig} {R V : Type} → Step S → R × V × Trace S → R × V × Trace S
cons1 m e = fst e , fst (snd e) , m ∷ snd (snd e)

-- play 与 mapF、>>= 交换（驱动器的定理要用）
module PlayLaws {S : Sig} {W : Type} (C : Comodel S W) where
  open Play C

  play-mapF : {A B : Type} (g : A → B) (P : Free S A) (w : W)
            → play (mapF g P) w ≡ (g (fst (play P w)) , fst (snd (play P w)) , snd (snd (play P w)))
  play-mapF g (done a)   w = refl
  play-mapF g (move o k) w =
    cong (λ e → fst e , fst (snd e) , (o , fst (resp C w o)) ∷ snd (snd e))
         (play-mapF g (k (fst (resp C w o))) (snd (resp C w o)))

  play->>= : {A B : Type} (P : Free S A) (f : A → Free S B) (w : W)
           → play (P >>= f) w
           ≡ ( fst (play (f (fst (play P w))) (fst (snd (play P w))))
             , fst (snd (play (f (fst (play P w))) (fst (snd (play P w)))))
             , snd (snd (play P w)) ++ snd (snd (play (f (fst (play P w))) (fst (snd (play P w))))) )
  play->>= (done a)   f w = refl
  play->>= (move o k) f w =
    cong (λ e → fst e , fst (snd e) , (o , fst (resp C w o)) ∷ snd (snd e))
         (play->>= (k (fst (resp C w o))) f (snd (resp C w o)))

------------------------------------------------------------------------
-- S1 状态 = 棋谱的 fold
--   resume P t   把录音 t 一条一条喂给程序 P：先核对"程序这一步就是录音这一步"（dec），
--                对上了，把录音里的回应喂给续体，接着喂下一条。
--                录音放完 → 交出余程序（inl）；程序先走到 done → 交出结果（inr）；
--                对不上 → 停在这一步，交出余程序（录音从这里作废，这一步要问真对手）。
--   next P t     余程序的头一步：驱动器问的"录音到此，下一步是什么"。
--   定理 next-play：对任何对手、任何起点，把 play 跑出的棋谱前 n 条喂进去，
--                next 给出的恰是棋谱第 n+1 条的步；resume-play：整条喂完，程序正好停在 play 的结果上。
------------------------------------------------------------------------
module Resume {S : Sig} (dec : Discrete (Op S)) where

  resume : {R : Type} → Free S R → Trace S → Free S R ⊎ R
  resume (done a)   t               = inr a
  resume (move o k) []              = inl (move o k)
  resume (move o k) ((o′ , r′) ∷ t) =
    decRec (λ p → resume (k (subst (Res S) (sym p) r′)) t) (λ _ → inl (move o k)) (dec o o′)

  headOp : {R : Type} → Free S R ⊎ R → Maybe (Op S)
  headOp (inl (done a))   = nothing
  headOp (inl (move o k)) = just o
  headOp (inr a)          = nothing

  next : {R : Type} → Free S R → Trace S → Maybe (Op S)
  next P t = headOp (resume P t)

  -- 棋谱的头一步
  headT : Trace S → Maybe (Op S)
  headT []            = nothing
  headT ((o , r) ∷ t) = just o

  -- 自己对自己的核对一定成功，回应原样交出（可判定 ⇒ Op 是集合，自环路径就是 refl）
  resume-hit : {R : Type} (o : Op S) (k : Res S o → Free S R) (r : Res S o) (t : Trace S)
             → resume (move o k) ((o , r) ∷ t) ≡ resume (k r) t
  resume-hit o k r t = lemma (dec o o)
    where
      lemma : (d : Dec (o ≡ o))
            → decRec (λ p → resume (k (subst (Res S) (sym p) r)) t) (λ _ → inl (move o k)) d ≡ resume (k r) t
      lemma (yes p) = cong (λ q → resume (k (subst (Res S) (sym q) r)) t) (Discrete→isSet dec o o p refl)
                    ∙ cong (λ x → resume (k x) t) (transportRefl r)
      lemma (no ¬p) = ⊥rec (¬p refl)

  module _ {W : Type} (C : Comodel S W) where
    open Play C

    next-play : {R : Type} (P : Free S R) (w : W) (n : ℕ)
              → next P (take n (snd (snd (play P w)))) ≡ headT (drop n (snd (snd (play P w))))
    next-play (done a)   w zero    = refl
    next-play (done a)   w (suc n) = refl
    next-play (move o k) w zero    = refl
    next-play (move o k) w (suc n) =
        cong headOp (resume-hit o k (fst (resp C w o)) (take n (snd (snd (play (k (fst (resp C w o))) (snd (resp C w o)))))))
      ∙ next-play (k (fst (resp C w o))) (snd (resp C w o)) n

    resume-play : {R : Type} (P : Free S R) (w : W) → resume P (snd (snd (play P w))) ≡ inr (fst (play P w))
    resume-play (done a)   w = refl
    resume-play (move o k) w =
        resume-hit o k (fst (resp C w o)) (snd (snd (play (k (fst (resp C w o))) (snd (resp C w o)))))
      ∙ resume-play (k (fst (resp C w o))) (snd (resp C w o))
