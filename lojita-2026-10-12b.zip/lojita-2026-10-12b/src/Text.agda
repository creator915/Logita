{-# OPTIONS --safe --cubical #-}
------------------------------------------------------------------------
-- Text.agda —— 文本可判定相等：世界的值、语法树的串字面量都要它
--   Agda 的内建串/字符带两条单射原语（不是公设，--safe 允许）；
--   它们用的是归纳的相等 _≡p_，经 Cubical.Data.Equality 换成路径。
------------------------------------------------------------------------
module Text where

open import Cubical.Foundations.Prelude
open import Cubical.Relation.Nullary
open import Cubical.Data.Nat.Properties using (discreteℕ)
open import Cubical.Data.List.Properties using (discreteList)
open import Cubical.Data.Equality.Conversion using (eqToPath ; pathToEq)
open import Agda.Builtin.Char public using (Char ; primCharToNat)
open import Agda.Builtin.String public using (String ; primStringToList ; primStringAppend)
open import Agda.Builtin.Char.Properties using (primCharToNatInjective)
open import Agda.Builtin.String.Properties using (primStringToListInjective)

discreteChar : Discrete Char
discreteChar a b with discreteℕ (primCharToNat a) (primCharToNat b)
... | yes p = yes (eqToPath (primCharToNatInjective a b (pathToEq p)))
... | no ¬p = no (λ q → ¬p (cong primCharToNat q))

discreteString : Discrete String
discreteString a b with discreteList discreteChar (primStringToList a) (primStringToList b)
... | yes p = yes (eqToPath (primStringToListInjective a b (pathToEq p)))
... | no ¬p = no (λ q → ¬p (cong primStringToList q))

isSetString : isSet String
isSetString = Discrete→isSet discreteString

_++ˢ_ : String → String → String
_++ˢ_ = primStringAppend
