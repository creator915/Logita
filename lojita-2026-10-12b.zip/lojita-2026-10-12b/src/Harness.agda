{-# OPTIONS --safe --cubical #-}
------------------------------------------------------------------------
-- Harness.agda —— 整个范畴的骨架（三层塔）
--   底      配置 x（规则书 + 能开的子配置 + 每条边上的运输），一棵树
--   纤维    Fiber x：对象 = 棋盘，箭头 = 在 x 下合法的棋谱
--   纤维里  程序（策略） 对上 对手（预言机 × 世界 × 子 harness）
--   诚实    Honest：一步一步按 Mach x 走的对手。执行者、录音器的唯一义务
--   定理    任何诚实的对手、任何策略，跑出来的棋谱都是 Fiber x 里的一条箭头
-- 没有全局公理：预言机、世界、数据库、运输……全是下面这个模块的参数。
------------------------------------------------------------------------
open import Cubical.Foundations.Prelude
open import Cubical.Foundations.HLevels
open import Cubical.Data.Nat using (ℕ ; zero ; suc)
open import Cubical.Data.Bool.Base using (Bool ; true ; false)
open import Cubical.Data.Sigma
open import Cubical.Data.List
open import Cubical.Data.Maybe
open import Game
open import PathCat

module Harness
  -- ① 预言机：智能与外部性的来源（LLM、人、时钟……）。只受类型约束，内容是参数
  (Oracle : Type) (Q : Oracle → Type) (A : Oracle → Type)
  (OState : Type) (oracle : OState → (o : Oracle) → Q o → A o × OState)
  -- ② 世界：对象层的签名与数据库（Store.agda 交出这五样）
  (WSig : Sig) (Board : Type) (isSetBoard : isSet Board)
  (isSetWRes : ∀ o → isSet (Res WSig o))
  (world : Board → (o : Op WSig) → Res WSig o × Board)
  -- ③ 子线两端传的数据
  (Spec Report : Type)
  -- ④ 运输：kid 边上面，棋盘怎么下去（restrict）、怎么回来（merge）
  --    运输是数据（Lifting），解释成两个函数；Store.Lifts 给出 whole / realm 两种
  (Lifting : Type) (restrict : Lifting → Board → Board) (merge : Lifting → Board → Board → Board)
  where

------------------------------------------------------------------------
-- §0 对象层：世界是一个确定的对手；事务范畴
------------------------------------------------------------------------
Store : Comodel WSig Board
Store = record { resp = world }

Trans : Category
Trans = Build.Cat (Det.MachOf Store isSetBoard isSetWRes)

------------------------------------------------------------------------
-- §1 底：配置 = 规则书 + 孩子 + 每条边上的运输
------------------------------------------------------------------------
record Rules : Type₁ where
  field
    Tool        : Type
    Call        : Tool → Type
    Result      : Tool → Type
    isSetResult : ∀ t → isSet (Result t)
    impl        : (t : Tool) → Call t → Free WSig (Result t)
open Rules public

-- 子配置在开子线时就定了，整条子线不换；运输也定在边上（结构，不是执行者的事）
data Config : Type₁ where
  node : (r : Rules) (Kids : Type) (kid : Kids → Config) (lf : Kids → Lifting) → Config

------------------------------------------------------------------------
-- §2 一层能走的三类步，与它们的回应：配置的签名
------------------------------------------------------------------------
data Act (r : Rules) (Kids : Type) : Type where
  ask : (o : Oracle) → Q o → Act r Kids          -- 问预言机
  run : (t : Tool r) → Call r t → Act r Kids      -- 动世界（走一次事务）
  sub : (k : Kids) → Spec → Act r Kids            -- 开子线

Sig-of : Config → Sig
Sig-of (node r Kids kid lf) = record { Op = Act r Kids ; Res = res }
  where
    res : Act r Kids → Type
    res (ask o q)  = A o
    res (run t c)  = Result r t
    res (sub k sp) = Report × Trace (Sig-of (kid k))   -- 回报 + 子棋谱

KidsOf : Config → Type
KidsOf (node r Kids kid lf) = Kids
kidOf : (x : Config) → KidsOf x → Config
kidOf (node r Kids kid lf) = kid
liftOf : (x : Config) → KidsOf x → Lifting
liftOf (node r Kids kid lf) = lf

-- 策略树：形状跟着配置树走
record Strat (x : Config) : Type where
  inductive
  no-eta-equality
  field
    prog : Spec → Free (Sig-of x) Report
    kids : (k : KidsOf x) → Strat (kidOf x k)
open Strat public

------------------------------------------------------------------------
-- §3 纤维：在 x 下什么棋谱合法（静态：不看预言机的内部、不看执行者）
------------------------------------------------------------------------
exec : (r : Rules) (t : Tool r) → Call r t → Board → Result r t × Board
exec r t c b = let e = Play.play Store (impl r t c) b in fst e , fst (snd e)

Mach : (x : Config) → Machine Board (Step (Sig-of x))

okOf : (x : Config) → Board → Step (Sig-of x) → Board → Type
okOf (node r Kids kid lf) b (ask o q  , a)         b′ = b ≡ b′
okOf (node r Kids kid lf) b (run t c  , rs)        b′ = exec r t c b ≡ (rs , b′)
okOf (node r Kids kid lf) b (sub k sp , (rep , t)) b′ =      -- 子线：下去、子棋谱合法、回来
  Σ[ c ∈ Board ] (Build.Legal (Mach (kid k)) (restrict (lf k) b) t c × (merge (lf k) b c ≡ b′))

okPropOf : (x : Config) → ∀ b m b′ → isProp (okOf x b m b′)
okPropOf (node r Kids kid lf) b (ask o q  , a)         b′ = isSetBoard b b′
okPropOf (node r Kids kid lf) b (run t c  , rs)        b′ = isSet× (isSetResult r t) isSetBoard _ _
okPropOf (node r Kids kid lf) b (sub k sp , (rep , t)) b′ (c₁ , l₁ , e₁) (c₂ , l₂ , e₂) =
  ΣPathP (Build.legalDet (Mach (kid k)) t l₁ l₂ ,
          toPathP (isProp× (Build.isPropLegal (Mach (kid k)) _ t c₂) (isSetBoard _ _) _ _))

okDetOf : (x : Config) → ∀ b m {b′ b″} → okOf x b m b′ → okOf x b m b″ → b′ ≡ b″
okDetOf (node r Kids kid lf) b (ask o q  , a)         e e′ = sym e ∙ e′
okDetOf (node r Kids kid lf) b (run t c  , rs)        e e′ = cong snd (sym e ∙ e′)
okDetOf (node r Kids kid lf) b (sub k sp , (rep , t)) (c₁ , l₁ , e₁) (c₂ , l₂ , e₂) =
  sym e₁ ∙ cong (merge (lf k) b) (Build.legalDet (Mach (kid k)) t l₁ l₂) ∙ e₂

Mach x = record
  { ok = okOf x ; isSetPos = isSetBoard
  ; okProp = okPropOf x ; okDet = λ {b} {m} → okDetOf x b m }

Fiber : Config → Category
Fiber x = Build.Cat (Mach x)

transOf : (r : Rules) (t : Tool r) (c : Call r t) (b : Board)
        → Category.Hom Trans b (snd (exec r t c b))
transOf r t c b = snd (snd (Play.play Store (impl r t c) b))
                , Det.soundDet Store isSetBoard isSetWRes (impl r t c) b

------------------------------------------------------------------------
-- §4 诚实的对手，与执行者
--   Honest：对手每答一步，都是 Mach x 的一步（在棋盘投影 board 下）。
--   结构（Mach x）不知道对手是谁；对手只需要诚实。真对手、录音对手都诚实（见 Dynamics、Replay）。
------------------------------------------------------------------------
Honest : (x : Config) {W : Type} → Comodel (Sig-of x) W → (W → Board) → Type
Honest x C board = ∀ w o → okOf x (board w) (o , fst (resp C w o)) (board (snd (resp C w o)))

-- 诚实 ⇒ 整局合法：一步一步接起来
soundHonest : (x : Config) {W : Type} (C : Comodel (Sig-of x) W) (board : W → Board) → Honest x C board
            → {R : Type} (P : Free (Sig-of x) R) (w : W)
            → Build.Legal (Mach x) (board w) (snd (snd (Play.play C P w))) (board (fst (snd (Play.play C P w))))
soundHonest x C board h (done a)   w = refl
soundHonest x C board h (move o k) w =
  board (snd (resp C w o)) , h w o , soundHonest x C board h (k (fst (resp C w o))) (snd (resp C w o))

-- 执行者：拿一个诚实的对手和一个程序，跑出（结果、终态、棋谱），并担保棋谱合法。
-- 这是 à la Carte 的 Scheduler 槽：结构只要求这一个证明字段，不规定怎么跑。
-- 默认 = Play.play（suspending：开了就跑到底）。中止/并发的执行者要改 Σ，到时填进同一个槽。
record Exec : Type₁ where
  field
    execute : (x : Config) {W : Type} (C : Comodel (Sig-of x) W) (board : W → Board) → Honest x C board
        → {R : Type} → Free (Sig-of x) R → W → R × W × Trace (Sig-of x)
    execute-sound : (x : Config) {W : Type} (C : Comodel (Sig-of x) W) (board : W → Board) (h : Honest x C board)
              → {R : Type} (P : Free (Sig-of x) R) (w : W)
              → Build.Legal (Mach x) (board w) (snd (snd (execute x C board h P w))) (board (fst (snd (execute x C board h P w))))

playExec : Exec
playExec = record { execute = λ x C board h P w → Play.play C P w ; execute-sound = soundHonest }

------------------------------------------------------------------------
-- §5 对手族（动态）：预言机 × 世界 × 子 harness，沿 sub 边用三个 lens 下去、回来
--   棋盘：restrict / merge（结构，定在边上）
--   预言机状态：原样传给孩子、原样收回（共享会话；独立会话 = 把它并进 X）
--   X：上下文的其余部分——资源账的位子。enter = 对父的 Σ 做一次更新（扣账），leave = 归还
------------------------------------------------------------------------
module Dynamics (X : Type) (enter : X → Spec → X) (leave : X → X → X) (E : Exec) where

  W : Type
  W = OState × Board × X

  board : W → Board
  board (s , b , xx) = b

  opp    : (x : Config) → Strat x → Comodel (Sig-of x) W
  honest : (x : Config) (st : Strat x) → Honest x (opp x st) board
  respOf : (x : Config) → Strat x → W → (m : Op (Sig-of x)) → Res (Sig-of x) m × W

  respOf (node r Kids kid lf) st (s , b , xx) (ask o q) = let e = oracle s o q in fst e , (snd e , b , xx)
  respOf (node r Kids kid lf) st (s , b , xx) (run t c) = let e = exec r t c b   in fst e , (s , snd e , xx)
  respOf (node r Kids kid lf) st (s , b , xx) (sub k sp) =
    let e  = Exec.execute E (kid k) (opp (kid k) (kids st k)) board (honest (kid k) (kids st k))
                        (prog (kids st k) sp) (s , restrict (lf k) b , enter xx sp)   -- 下去
        w′ = fst (snd e)
    in (fst e , snd (snd e)) , (fst w′ , merge (lf k) b (board w′) , leave xx (snd (snd w′)))   -- 回来
  opp x st = record { resp = respOf x st }

  honest (node r Kids kid lf) st (s , b , xx) (ask o q) = refl
  honest (node r Kids kid lf) st (s , b , xx) (run t c) = refl
  honest (node r Kids kid lf) st (s , b , xx) (sub k sp) =
    board (fst (snd e))
    , Exec.execute-sound E (kid k) (opp (kid k) (kids st k)) board (honest (kid k) (kids st k))
                       (prog (kids st k) sp) (s , restrict (lf k) b , enter xx sp)
    , refl
    where
      e = Exec.execute E (kid k) (opp (kid k) (kids st k)) board (honest (kid k) (kids st k))
                     (prog (kids st k) sp) (s , restrict (lf k) b , enter xx sp)

  -- 一局的产出
  endOf   : (x : Config) (st : Strat x) {R : Type} → Free (Sig-of x) R → W → Board
  endOf   x st P w = board (fst (snd (Play.play (opp x st) P w)))
  traceOf : (x : Config) (st : Strat x) {R : Type} → Free (Sig-of x) R → W → Trace (Sig-of x)
  traceOf x st P w = snd (snd (Play.play (opp x st) P w))

  -- §6 定理：对任何策略、任何预言机、任何执行者、任何运输，跑出的棋谱在 Fiber x 里合法
  sound : (x : Config) (st : Strat x) {R : Type} (P : Free (Sig-of x) R) (w : W)
        → Build.Legal (Mach x) (board w) (traceOf x st P w) (endOf x st P w)
  sound x st = soundHonest x (opp x st) board (honest x st)

  -- 局面 = 棋盘 + 从起点到它的合法棋谱；一局跑完 = 一个局面
  Position : Config → Board → Type
  Position x b₀ = Σ[ b ∈ Board ] Build.Hom (Mach x) b₀ b

  finish : (x : Config) (st : Strat x) {R : Type} (P : Free (Sig-of x) R) (w : W) → Position x (board w)
  finish x st P w = endOf x st P w , traceOf x st P w , sound x st P w

-- 产品 = 终局棋盘 + 验收证明
Product : (Accept : Board → Type) → Type
Product Accept = Σ[ b ∈ Board ] Accept b

------------------------------------------------------------------------
-- §7 反射点：一回合 = 问预言机 → check → 走一步
--   check 拿到回答之后决定走不走、走哪步；它自己也是一段程序（可以再问一步，例如问检查器：
--   反射是预言机里的一步）。纯的 check 就是 done ∘ f。
--   rounds：题单就是预算，每个问题一回合；某回合 check 说不走（nothing）就收，交出走成的回合数。
--   x 作为参数传进来再拆开（不在模块参数里重新拼 node：λ () 拼两次不是同一个函数）。
------------------------------------------------------------------------
module Reflect (llm : Oracle) where

  Check : Config → Type
  Check x = Q llm → A llm → Free (Sig-of x) (Maybe (Op (Sig-of x)))

  turn : (x : Config) → Check x → Q llm → Free (Sig-of x) (Maybe (Step (Sig-of x)))
  turn (node r Kids kid lf) chk q = move (ask llm q) (λ a → chk q a >>= go)
    where
      go : Maybe (Act r Kids) → Free (Sig-of (node r Kids kid lf)) (Maybe (Step (Sig-of (node r Kids kid lf))))
      go nothing  = done nothing
      go (just m) = move m (λ rs → done (just (m , rs)))

  rounds : (x : Config) → Check x → List (Q llm) → Free (Sig-of x) ℕ
  rounds x chk = loop 0
    where
      loop : ℕ → List (Q llm) → Free (Sig-of x) ℕ
      loop n []       = done n
      loop n (q ∷ qs) = turn x chk q >>= after
        where
          after : Maybe (Step (Sig-of x)) → Free (Sig-of x) ℕ
          after nothing  = done n
          after (just _) = loop (suc n) qs

-- 题单：每一题是一段程序，交出这一题走成没有；没走成就收，交出走成的题数。
--   rounds 是它的特例（每一题都是一回合 turn）；题也可以是"开一条子线"——
--   那时这一层不问预言机，整回合在孩子里做（ToyText：程序从不穿过子线边界）。
agenda : (x : Config) {T : Type} → (T → Free (Sig-of x) Bool) → List T → Free (Sig-of x) ℕ
agenda x {T} step = loop 0
  where
    loop : ℕ → List T → Free (Sig-of x) ℕ
    loop n []       = done n
    loop n (t ∷ ts) = step t >>= after
      where
        after : Bool → Free (Sig-of x) ℕ
        after false = done n
        after true  = loop (suc n) ts

------------------------------------------------------------------------
-- §8 三层塔，与 à la Carte 的槽
--  层    环境（范畴）     状态（点）        一步              由谁答
--  编排  Config 树        x : Config        ▽ 开子线 (k , sp)  程序经 check 决定
--  代理  Fiber x          b : Board         ask / run / sub   预言机 / 世界 / 子 harness
--  对象  Trans            b : Board         WSig 的一步        世界（确定）
--  槽：  Lifting（每条边的运输，结构）× (X, enter, leave)（上下文 lens）× Exec（执行者）× 对手（真 / 录音）
--        结构只认 Honest；换槽里的东西，sound 不动。
------------------------------------------------------------------------

------------------------------------------------------------------------
-- §9 驱动器：同一个程序的第二个解释器
--   OSig 只有一种步：问预言机 (o , q)，回应 A o。
--   drive = Dynamics.opp 把 ask 那一行换成 move（交出去），run / sub 照抄（世界在模型内，Agda 自己算）。
--   OSig 的余模型住在机外（后端：问 LLM、checkInternal）；在 Agda 里拿 oracle 本身当余模型，
--   定理 drive-agrees：两个解释器跑出同一个结果、同一个终局、同一条棋谱（dev-order 第 2 把尺）。
------------------------------------------------------------------------
OSig : Sig
OSig = record { Op = Σ Oracle Q ; Res = λ oq → A (fst oq) }

oracleC : Comodel OSig OState
oracleC = record { resp = λ s oq → oracle s (fst oq) (snd oq) }

module Drive (X : Type) (enter : X → Spec → X) (leave : X → X → X) where

  WD : Type                                   -- 驱动器的状态：没有预言机的那一份（它在机外）
  WD = Board × X

  drive : (x : Config) → Strat x → {R : Type} → Free (Sig-of x) R → WD
        → Free OSig (R × WD × Trace (Sig-of x))
  drive x st (done a) w = done (a , w , [])
  drive (node r Kids kid lf) st (move (ask o q) k) (b , xx) =             -- 交出去：等机外的回答
    move (o , q) λ a → mapF (cons1 (ask o q , a)) (drive (node r Kids kid lf) st (k a) (b , xx))
  drive (node r Kids kid lf) st (move (run t c) k) (b , xx) =             -- 世界：照抄 opp
    mapF (cons1 (run t c , fst (exec r t c b)))
         (drive (node r Kids kid lf) st (k (fst (exec r t c b))) (snd (exec r t c b) , xx))
  drive (node r Kids kid lf) st (move (sub k′ sp) k) (b , xx) =           -- 子线：下去、跑完、回来
    drive (kid k′) (kids st k′) (prog (kids st k′) sp) (restrict (lf k′) b , enter xx sp) >>= λ e →
      mapF (cons1 (sub k′ sp , (fst e , snd (snd e))))
           (drive (node r Kids kid lf) st (k (fst e , snd (snd e)))
                  (merge (lf k′) b (fst (fst (snd e))) , leave xx (snd (fst (snd e)))))

  module DP = Dynamics X enter leave playExec
  open PlayLaws oracleC

  -- 驱动器在 oracleC 下跑完的产出，摆成 opp 的形状（预言机状态塞回中间；OSig 自己的棋谱丢掉）
  shape : {R T : Type} → (R × WD × T) × OState × Trace OSig → R × DP.W × T
  shape e = fst (fst e) , (fst (snd e) , fst (fst (snd (fst e))) , snd (fst (snd (fst e)))) , snd (snd (fst e))

  drive-agrees : (x : Config) (st : Strat x) {R : Type} (P : Free (Sig-of x) R) (s : OState) (b : Board) (xx : X)
               → Play.play (DP.opp x st) P (s , b , xx) ≡ shape (Play.play oracleC (drive x st P (b , xx)) s)
  drive-agrees x st (done a) s b xx = refl
  drive-agrees (node r Kids kid lf) st (move (ask o q) k) s b xx =
      cong (cons1 (ask o q , fst (oracle s o q)))
           (drive-agrees (node r Kids kid lf) st (k (fst (oracle s o q))) (snd (oracle s o q)) b xx)
    ∙ cong shape (sym (play-mapF (cons1 (ask o q , fst (oracle s o q)))
                                 (drive (node r Kids kid lf) st (k (fst (oracle s o q))) (b , xx))
                                 (snd (oracle s o q))))
  drive-agrees (node r Kids kid lf) st (move (run t c) k) s b xx =
      cong (cons1 (run t c , fst (exec r t c b)))
           (drive-agrees (node r Kids kid lf) st (k (fst (exec r t c b))) s (snd (exec r t c b)) xx)
    ∙ cong shape (sym (play-mapF (cons1 (run t c , fst (exec r t c b)))
                                 (drive (node r Kids kid lf) st (k (fst (exec r t c b))) (snd (exec r t c b) , xx))
                                 s))
  drive-agrees (node r Kids kid lf) st {R} (move (sub k′ sp) k) s b xx =
      cong after (drive-agrees (kid k′) (kids st k′) (prog (kids st k′) sp) s (restrict (lf k′) b) (enter xx sp))
    ∙ cong (cons1 (sub k′ sp , (fst (fst e₁) , snd (snd (fst e₁)))))
           (drive-agrees (node r Kids kid lf) st (k (fst (fst e₁) , snd (snd (fst e₁)))) (fst (snd e₁))
                         (merge (lf k′) b (fst (fst (snd (fst e₁))))) (leave xx (snd (fst (snd (fst e₁))))))
    ∙ cong shape (sym (play-mapF (cons1 (sub k′ sp , (fst (fst e₁) , snd (snd (fst e₁)))))
                                 (drive (node r Kids kid lf) st (k (fst (fst e₁) , snd (snd (fst e₁))))
                                        (merge (lf k′) b (fst (fst (snd (fst e₁)))) , leave xx (snd (fst (snd (fst e₁))))))
                                 (fst (snd e₁))))
    ∙ cong shape (sym (play->>= (drive (kid k′) (kids st k′) (prog (kids st k′) sp) (restrict (lf k′) b , enter xx sp))
                                (λ e → mapF (cons1 (sub k′ sp , (fst e , snd (snd e))))
                                            (drive (node r Kids kid lf) st (k (fst e , snd (snd e)))
                                                   (merge (lf k′) b (fst (fst (snd e))) , leave xx (snd (fst (snd e))))))
                                s))
    where
      x = node r Kids kid lf
      e₁ = Play.play oracleC (drive (kid k′) (kids st k′) (prog (kids st k′) sp) (restrict (lf k′) b , enter xx sp)) s
      -- 子线跑完之后，父亲这边接着走（opp 的写法，参数是子线的产出）
      after : Report × DP.W × Trace (Sig-of (kid k′)) → R × DP.W × Trace (Sig-of x)
      after E = cons1 (sub k′ sp , (fst E , snd (snd E)))
                      (Play.play (DP.opp x st) (k (fst E , snd (snd E)))
                                 (fst (fst (snd E)) , merge (lf k′) b (fst (snd (fst (snd E)))) , leave xx (snd (snd (fst (snd E))))))
