{-# OPTIONS --safe --cubical #-}
------------------------------------------------------------------------
-- ToyText.agda —— P3：文本世界上的真工具。LLM 写值和程序（数据），检查器把它们变成控制
--   世界    Store：键 = 文件号 ℕ，值 = 文本 String
--   工具    根上 readK / writeK，子线上 evalP——都从 Code.Tools 的表生成
--   题单    keyTask k ：根自己做一回合：问 LLM 键 k 的新内容 → 查（码 maybe text）→ writeK
--           codeTask t：开子线，只传任务文本 t；子线里做整回合：问 LLM 写程序 → 查（码 program unit）→ run evalP
--   守卫    只有一层、只能挡：子线的运输是 realm white，白名单外的键看不见、写不回（Store 的 confineL）
--   程序    在子线里产生、在子线里用掉，从不穿过子线边界：根这一层的步全部可判定（§7 decRootOp）；
--           不可判定的只剩子线里 evalP 的调用参数一处（录音对位留给 P5）
--   §6 用玩具检查器在 Agda 里跑一局（全部 refl）   §7 可判定性与 verify   §8 驱动器：后端来答
------------------------------------------------------------------------
module ToyText where

open import Cubical.Foundations.Prelude
open import Cubical.Relation.Nullary
open import Cubical.Data.Nat
open import Cubical.Data.Nat.Properties using (discreteℕ ; isSetℕ)
open import Cubical.Data.Bool.Base
open import Cubical.Data.Maybe
open import Cubical.Data.Maybe.Properties using (discreteMaybe)
open import Cubical.Data.Sigma
open import Cubical.Data.Sigma.Properties using (discreteΣ)
open import Cubical.Data.Sum using (_⊎_ ; inl ; inr)
open import Cubical.Data.Unit
open import Cubical.Data.Unit.Properties using (isSetUnit)
open import Cubical.Data.Empty
open import Cubical.Data.List
open import Game
open import Text

------------------------------------------------------------------------
-- 1 世界：键 = 文件号，值 = 文本
------------------------------------------------------------------------
import Store
module DB = Store ℕ String discreteℕ discreteString
open DB

-- LLM 写程序时可以用的名字（它的词汇表）
rd : ℕ → Free WSig (Maybe String)
rd k = move (get k) done

wr : ℕ → String → Free WSig Unit
wr k v = move (set k v) (λ _ → done tt)

orElse : String → Maybe String → String      -- 读不到时的默认值
orElse d nothing  = d
orElse d (just s) = s

------------------------------------------------------------------------
-- 2 代码：名字与洞都编成 ℕ；世界签名 = 数据库的
------------------------------------------------------------------------
import Code
module C = Code ℕ ℕ WSig
open C

import CodeDec
module CD = CodeDec ℕ discreteℕ ℕ discreteℕ WSig

------------------------------------------------------------------------
-- 3 题与槽
--   问 LLM 的题（Ask）带着说明一起进提示词；检查器的槽（Fp）决定码
------------------------------------------------------------------------
data Ask : Type where
  fillKey   : ℕ → Ask              -- 给键 k 写新内容
  writeCode : String → Ask         -- 按这段任务文本写一段对世界的程序

data Fp : Type where
  valSlot  : ℕ → Fp
  progSlot : Fp

codeOf : Fp → U
codeOf (valSlot k) = maybe text
codeOf progSlot    = program unit

module CK = Checker Unit (λ _ → Ask) (λ _ → Raw) Fp codeOf
open CK

-- 玩具替身（只在 Agda 里跑 refl 用；真跑时这两样换成后端）
llmF : List Raw → (o : Unit) → Ask → Raw × List Raw          -- 脚本 LLM；脚本空了答一个查不过的树
llmF []       _ _ = sort 0 , []
llmF (r ∷ rs) _ _ = r , rs

-- 玩具检查器：只认三种树形——wr 的调用、just 串。
-- 名字表与后端一致：后端按名字第一次出现的先后编号（脚本里 wr 先出现 = 0，just = 1）
chkT : Unit → (f : Fp) → Raw → Maybe (El (codeOf f)) × Unit
chkT _ progSlot (def 0 (app vis (lit (natL k)) ∷ app vis (lit (strL s)) ∷ [])) = just (wr k s) , tt
chkT _ (valSlot _) (con 1 (app vis (lit (strL s)) ∷ [])) = just (just s) , tt
chkT _ _ _ = nothing , tt

module OD = Dyn {List Raw} {Unit} llmF chkT
open OD

------------------------------------------------------------------------
-- 4 装上 Harness：Spec = 任务文本（可判定），Report = ℕ（子线走成的回合数）
------------------------------------------------------------------------
import Harness
module H = Harness Oracle Q A OState oracle WSig Board isSetBoard isSetWRes world
                   String ℕ Lifting restrictL mergeL
open H

-- 工具表 → 规则书（Code.Tools 算出 Call / Result / impl）
rulesOf : (T : Type) → (T → ToolEntry) → Rules
rulesOf T tab = record { Tool = T ; Call = TT.Call ; Result = TT.Result
                       ; isSetResult = TT.isSetResult ; impl = TT.impl }
  where module TT = Tools T tab

data RTool : Type where
  readK writeK : RTool

rtab : RTool → ToolEntry
rtab readK  = record { callU = nat ; resU = maybe text
                     ; isSetRes = isOfHLevelMaybe 0 isSetString ; body = rd }
rtab writeK = record { callU = σ nat (λ _ → text) ; resU = unit
                     ; isSetRes = isSetUnit ; body = λ kv → wr (fst kv) (snd kv) }

data PTool : Type where
  evalP : PTool

ptab : PTool → ToolEntry
ptab evalP = record { callU = program unit ; resU = unit ; isSetRes = isSetUnit ; body = λ p → p }

Rroot Rrun : Rules
Rroot = rulesOf RTool rtab
Rrun  = rulesOf PTool ptab

------------------------------------------------------------------------
-- 5 配置树与策略
------------------------------------------------------------------------
white : ℕ → Bool                       -- 白名单：0、1、2 号文件
white 0 = true
white 1 = true
white 2 = true
white _ = false

runner : Config
runner = node Rrun ⊥ (λ ()) (λ ())

root : Config
root = node Rroot Unit (λ _ → runner) (λ _ → realm white)

module RF = Reflect (inl tt)

-- 子线：整回合在这里。问 LLM 写程序 → 交给 progSlot 的检查器 → 通过就 run evalP p
checkP : RF.Check runner
checkP (writeCode t) r = move (ask (inr progSlot) r) λ m → done (map-Maybe (run evalP) m)
checkP (fillKey k)   r = done nothing                       -- 写键的题不在子线里做

runnerProg : String → Free (Sig-of runner) ℕ             -- 一题；交出走成的回合数（0 或 1）
runnerProg t = RF.rounds runner checkP (writeCode t ∷ [])

stratRunner : Strat runner
stratRunner = record { prog = runnerProg ; kids = λ () }

-- 根：keyTask k 自己做一回合；codeTask t 开子线，只传文本
bindM : {X Y : Type} → Maybe X → (X → Maybe Y) → Maybe Y
bindM nothing  g = nothing
bindM (just x) g = g x

writeIt : ℕ → Maybe String → Maybe (Act Rroot Unit)
writeIt k (just v) = just (run writeK (k , v))
writeIt k nothing  = nothing                                -- LLM 说这个键不写：收

checkR : RF.Check root
checkR (fillKey k)   r = move (ask (inr (valSlot k)) r) λ m → done (bindM m (writeIt k))
checkR (writeCode t) r = done nothing                       -- 写代码的题交给子线

data Task : Type where
  keyTask  : ℕ → Task
  codeTask : String → Task

moved : {X : Type} → Maybe X → Bool
moved nothing  = false
moved (just _) = true

positive : ℕ → Bool
positive zero    = false
positive (suc _) = true

rootTask : Task → Free (Sig-of root) Bool
rootTask (keyTask k)  = RF.turn root checkR (fillKey k) >>= λ s → done (moved s)
rootTask (codeTask t) = move (sub tt t) λ rt → done (positive (fst rt))   -- 回报 = 子线走成的回合数

schedule : List Task                   -- 题单 = 预算
schedule = codeTask "把 hello 写进 2 号文件"
         ∷ keyTask 1
         ∷ codeTask "往 5 号文件写点东西"
         ∷ codeTask "再写一段"
         ∷ []

rootProg : Free (Sig-of root) ℕ        -- 先读 0 号文件（任务的输入），再按题单走
rootProg = move (run readK 0) λ _ → agenda root rootTask schedule

stratRoot : Strat root
stratRoot = record { prog = λ _ → rootProg ; kids = λ _ → stratRunner }

------------------------------------------------------------------------
-- 6 在 Agda 里跑一局（玩具替身）
--   脚本：wr 2 "hello"（子线的程序）、just "world"（根：1 号的新内容）、
--         wr 5 "evil"（子线：白名单外）、true（子线：查不过 → 子线回报 0 → 根收）
------------------------------------------------------------------------
module D = Dynamics Unit (λ x _ → x) (λ x _ → x) playExec
open D

b0 : Board
b0 = upd 0 (just "input text") (λ _ → nothing)

script : List Raw
script = def 0 (app vis (lit (natL 2)) ∷ app vis (lit (strL "hello")) ∷ [])
       ∷ con 1 (app vis (lit (strL "world")) ∷ [])
       ∷ def 0 (app vis (lit (natL 5)) ∷ app vis (lit (strL "evil")) ∷ [])
       ∷ con 2 []
       ∷ []

w0 : W
w0 = (script , tt) , b0 , tt

result : Position root b0
result = finish root stratRoot (prog stratRoot "") w0

theTrace : Trace (Sig-of root)
theTrace = fst (snd result)

final-0 : fst result 0 ≡ just "input text"
final-0 = refl

final-1 : fst result 1 ≡ just "world"
final-1 = refl

final-2 : fst result 2 ≡ just "hello"
final-2 = refl

final-5 : fst result 5 ≡ nothing          -- 写了，但在白名单外：子线回来时被运输挡住
final-5 = refl

steps : length theTrace ≡ 7               -- 根这一层 7 步：读、子线、问、查、写、子线、子线
steps = refl

------------------------------------------------------------------------
-- 7 可判定性与 verify
------------------------------------------------------------------------
import Replay
module RP = Replay Oracle Q A OState oracle WSig Board isSetBoard isSetWRes world
                   String ℕ Lifting restrictL mergeL
open RP using (VerCfg ; verify)

-- 根这一层的步全部可判定：题（Ask）、树（Raw）、工具调用（ℕ / ℕ × String）、子线的任务文本（String）
keyOfFp : Fp → ℕ
keyOfFp (valSlot k) = k
keyOfFp progSlot    = 0

isVal : Fp → Type
isVal (valSlot _) = Unit
isVal progSlot    = ⊥

decFp : Discrete Fp
decFp (valSlot k) (valSlot m) with discreteℕ k m
... | yes p = yes (cong valSlot p)
... | no ¬p = no (λ q → ¬p (cong keyOfFp q))
decFp progSlot    progSlot    = yes refl
decFp (valSlot _) progSlot    = no (λ p → subst isVal p tt)
decFp progSlot    (valSlot _) = no (λ p → subst isVal (sym p) tt)

keyOfAsk : Ask → ℕ
keyOfAsk (fillKey k)   = k
keyOfAsk (writeCode _) = 0

textOfAsk : Ask → String
textOfAsk (fillKey _)   = ""
textOfAsk (writeCode t) = t

isFill : Ask → Type
isFill (fillKey _)   = Unit
isFill (writeCode _) = ⊥

decAsk : Discrete Ask
decAsk (fillKey k) (fillKey m) with discreteℕ k m
... | yes p = yes (cong fillKey p)
... | no ¬p = no (λ q → ¬p (cong keyOfAsk q))
decAsk (writeCode s) (writeCode t) with discreteString s t
... | yes p = yes (cong writeCode p)
... | no ¬p = no (λ q → ¬p (cong textOfAsk q))
decAsk (fillKey _)   (writeCode _) = no (λ p → subst isFill p tt)
decAsk (writeCode _) (fillKey _)   = no (λ p → subst isFill (sym p) tt)

isRead : RTool → Type
isRead readK  = Unit
isRead writeK = ⊥

decRTool : Discrete RTool
decRTool readK  readK  = yes refl
decRTool writeK writeK = yes refl
decRTool readK  writeK = no (λ p → subst isRead p tt)
decRTool writeK readK  = no (λ p → subst isRead (sym p) tt)

decRCall : (t : RTool) → Discrete (Call Rroot t)
decRCall readK  = discreteℕ
decRCall writeK = discreteΣ discreteℕ (λ _ → discreteString)

module DA = RP.DecAct (decOracle (λ _ _ → yes refl) decFp) (decQ (λ _ → decAsk) CD.discreteRaw) discreteString

decRootOp : Discrete (Op (Sig-of root))
decRootOp = DA.decAct Rroot Unit decRTool decRCall (λ _ _ → yes refl)

-- 用一下：同一个子线任务判为相等，任务文本不同判为不等（都是 refl：判定真的算得出来）
answer : {X : Type} → Dec X → Bool
answer (yes _) = true
answer (no _)  = false

same-task : answer (decRootOp (sub tt "把 hello 写进 2 号文件") (sub tt "把 hello 写进 2 号文件")) ≡ true
same-task = refl

other-task : answer (decRootOp (sub tt "把 hello 写进 2 号文件") (sub tt "再写一段")) ≡ false
other-task = refl

-- verify 只要结果可判定（VerCfg）；子线里 evalP 的调用参数是程序，步不可判定，verify 不需要它
vcRun : VerCfg runner
vcRun = record { decResV = λ { evalP → λ _ _ → yes refl } ; kidsV = λ () }

vcRoot : VerCfg root
vcRoot = record { decResV = λ { readK → discreteMaybe discreteString ; writeK → λ _ _ → yes refl }
                ; kidsV = λ _ → vcRun }

-- 终局在 0、1、2、5 号键上的值
look : Board → List (Maybe String)
look b = b 0 ∷ b 1 ∷ b 2 ∷ b 5 ∷ []

verified : map-Maybe look (verify root vcRoot b0 theTrace)
         ≡ just (just "input text" ∷ just "world" ∷ just "hello" ∷ nothing ∷ [])
verified = refl

------------------------------------------------------------------------
-- 8 驱动器：同一个程序，ask 交给后端（--cubical-drive=driven）
--   (inl tt , 题)  问 LLM（题带着键号或任务文本进提示词；回答是 Agda 代码，后端解析后 quote 成 Raw）
--   (inr f , r)    checkInternal r : El (codeOf f)
------------------------------------------------------------------------
module DR = Drive Unit (λ x _ → x) (λ x _ → x)

driven : Free OSig (ℕ × DR.WD × Trace (Sig-of root))
driven = DR.drive root stratRoot (prog stratRoot "") (b0 , tt)

-- 在 Agda 里拿玩具预言机当余模型：棋谱与 §6 逐字相同（两个解释器一致）
driven-trace : snd (snd (fst (Play.play oracleC driven (script , tt)))) ≡ theTrace
driven-trace = refl

-- 后端跑完交给它们看
runTrace : ℕ × DR.WD × Trace (Sig-of root) → Trace (Sig-of root)
runTrace e = snd (snd e)

verifyRun : ℕ × DR.WD × Trace (Sig-of root) → Maybe (List (Maybe String))
verifyRun e = map-Maybe look (verify root vcRoot b0 (snd (snd e)))
